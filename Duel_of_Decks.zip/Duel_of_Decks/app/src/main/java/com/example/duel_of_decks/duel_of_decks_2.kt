package com.example.duel_of_decks

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.SystemClock
import android.view.View
import android.widget.Button
import android.widget.Chronometer
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import com.example.shane.R

private lateinit var chronometer: Chronometer
var round1 = true
var numround: Int = 0
var pauseOffSet: Long = 0
var player1 = false
var player2 = false
var p1points: Int = 100
var p2points: Int = 100
var cd1points: Int = 0
var cd2points: Int = 0
var click: Int = 0
var cardSelected1: Int = 0
var cardSelected2: Int = 0
var CardNumber1: Int = 0
var CardNumber2: Int = 0
var CardName1: String = ""
var CardName2: String = ""
var message: String = ""

class duel_of_decks_2 : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_duel_of_decks2)

        val secondActivityIntent: Intent = Intent(this, duel_of_decks_3::class.java)

        val round: TextView = findViewById(R.id.Round)
        val playerone: TextView = findViewById(R.id.P1)
        val playertwo: TextView = findViewById(R.id.P2)
        val card1: ImageView = findViewById(R.id.Card1)
        val card2: ImageView = findViewById(R.id.Card2)
        val card3: ImageView = findViewById(R.id.Card3)
        val card4: ImageView = findViewById(R.id.Card4)
        val submit: Button = findViewById(R.id.concluderound)

        chronometer = findViewById(R.id.chronometer1)

        if (round1) {
            round1 = false
            numround = 0
            player1 = false
            player2 = false
            p1points = 100
            p2points = 100
            cd1points = 0
            cd2points = 0
            click = 0
            pauseOffSet = 0
            message.equals("")
            CardName1.equals("")
            CardName2.equals("")
            cardSelected1 = 0
            cardSelected2 = 0
            CardNumber1 = 0
            CardNumber2 = 0
            chronometer.base = SystemClock.elapsedRealtime()

            chronometer.start()
            Toast.makeText(this, "Duel has began!", Toast.LENGTH_LONG).show()

            card1.setImageResource(R.drawable.card_1)
            card2.setImageResource(R.drawable.card_2)
            card3.setImageResource(R.drawable.card_5)
            card4.setImageResource(R.drawable.card_6)
            submit.visibility = View.GONE

            round.setText("Round: " + numround + " / 12")
            playerone.setText("Player 1: " + p1points)
            playertwo.setText("Player 2: " + p2points)

        } else {
        }
        card1.setOnClickListener {
            if (click.equals(0) && !player1) {
                player1 = true
                click = 1
//                Toast.makeText(this, "Player 1 has selected!", Toast.LENGTH_LONG).show()
                card1.setImageResource(R.drawable.p1_card_1)
                cardSelected1 = 1
                randInt()
            } else if (click.equals(1) && !player2 && cardSelected1 != 1) {
                player2 = true
                click = 2
//                Toast.makeText(this, "Player 2 has selected!", Toast.LENGTH_LONG).show()

                card1.setImageResource(R.drawable.p2_card_1)
                cardSelected2 = 1
                randInt1()
                Handler().postDelayed(
                    {
                        submit.visibility = View.VISIBLE
                if (cardSelected1.equals(1)) {
                    if (CardNumber1.equals(1)) {
                        card1.setImageResource(R.drawable.c1)
                    } else if (CardNumber1.equals(2)) {
                        card1.setImageResource(R.drawable.c2)
                    } else if (CardNumber1.equals(3)) {
                        card1.setImageResource(R.drawable.c3)
                    } else if (CardNumber1.equals(4)) {
                        card1.setImageResource(R.drawable.c4)
                    } else if (CardNumber1.equals(5)) {
                        card1.setImageResource(R.drawable.c5)
                    } else if (CardNumber1.equals(6)) {
                        card1.setImageResource(R.drawable.c6)
                    } else if (CardNumber1.equals(7)) {
                        card1.setImageResource(R.drawable.c7)
                    } else if (CardNumber1.equals(8)) {
                        card1.setImageResource(R.drawable.c8)
                    } else if (CardNumber1.equals(9)) {
                        card1.setImageResource(R.drawable.c9)
                    } else if (CardNumber1.equals(10)) {
                        card1.setImageResource(R.drawable.c10)
                    } else if (CardNumber1.equals(11)) {
                        card1.setImageResource(R.drawable.c11)
                    } else if (CardNumber1.equals(12)) {
                        card1.setImageResource(R.drawable.c12)
                    } else if (CardNumber1.equals(13)) {
                        card1.setImageResource(R.drawable.c13)
                    } else if (CardNumber1.equals(14)) {
                        card1.setImageResource(R.drawable.c14)
                    } else if (CardNumber1.equals(15)) {
                        card1.setImageResource(R.drawable.c15)
                    } else if (CardNumber1.equals(16)) {
                        card1.setImageResource(R.drawable.c16)
                    } else if (CardNumber1.equals(17)) {
                        card1.setImageResource(R.drawable.c17)
                    } else if (CardNumber1.equals(18)) {
                        card1.setImageResource(R.drawable.c18)
                    } else if (CardNumber1.equals(19)) {
                        card1.setImageResource(R.drawable.c19)
                    }  else if (CardNumber1.equals(20)) {
                        card1.setImageResource(R.drawable.c20)
                    } else if (CardNumber1.equals(21)) {
                        card1.setImageResource(R.drawable.c21)
                    } else if (CardNumber1.equals(22)) {
                        card1.setImageResource(R.drawable.c22)
                    } else if (CardNumber1.equals(23)) {
                        card1.setImageResource(R.drawable.c23)
                    } else if (CardNumber1.equals(24)) {
                        card1.setImageResource(R.drawable.c24)
                    } else if (CardNumber1.equals(25)) {
                        card1.setImageResource(R.drawable.c25)
                    } else if (CardNumber1.equals(26)) {
                        card1.setImageResource(R.drawable.c26)
                    } else if (CardNumber1.equals(27)) {
                        card1.setImageResource(R.drawable.c27)
                    } else if (CardNumber1.equals(28)) {
                        card1.setImageResource(R.drawable.c28)
                    } else if (CardNumber1.equals(29)) {
                        card1.setImageResource(R.drawable.c29)
                    } else {
                        card1.setImageResource(R.drawable.c30)
                    }
                } else if (cardSelected1.equals(2)) {
                    if (CardNumber1.equals(1)) {
                        card2.setImageResource(R.drawable.c1)
                    } else if (CardNumber1.equals(2)) {
                        card2.setImageResource(R.drawable.c2)
                    } else if (CardNumber1.equals(3)) {
                        card2.setImageResource(R.drawable.c3)
                    } else if (CardNumber1.equals(4)) {
                        card2.setImageResource(R.drawable.c4)
                    } else if (CardNumber1.equals(5)) {
                        card2.setImageResource(R.drawable.c5)
                    } else if (CardNumber1.equals(6)) {
                        card2.setImageResource(R.drawable.c6)
                    } else if (CardNumber1.equals(7)) {
                        card2.setImageResource(R.drawable.c7)
                    } else if (CardNumber1.equals(8)) {
                        card2.setImageResource(R.drawable.c8)
                    } else if (CardNumber1.equals(9)) {
                        card2.setImageResource(R.drawable.c9)
                    } else if (CardNumber1.equals(10)) {
                        card2.setImageResource(R.drawable.c10)
                    } else if (CardNumber1.equals(11)) {
                        card2.setImageResource(R.drawable.c11)
                    } else if (CardNumber1.equals(12)) {
                        card2.setImageResource(R.drawable.c12)
                    } else if (CardNumber1.equals(13)) {
                        card2.setImageResource(R.drawable.c13)
                    } else if (CardNumber1.equals(14)) {
                        card2.setImageResource(R.drawable.c14)
                    } else if (CardNumber1.equals(15)) {
                        card2.setImageResource(R.drawable.c15)
                    } else if (CardNumber1.equals(16)) {
                        card2.setImageResource(R.drawable.c16)
                    } else if (CardNumber1.equals(17)) {
                        card2.setImageResource(R.drawable.c17)
                    } else if (CardNumber1.equals(18)) {
                        card2.setImageResource(R.drawable.c18)
                    } else if (CardNumber1.equals(19)) {
                        card2.setImageResource(R.drawable.c19)
                    }  else if (CardNumber1.equals(20)) {
                        card2.setImageResource(R.drawable.c20)
                    } else if (CardNumber1.equals(21)) {
                        card2.setImageResource(R.drawable.c21)
                    } else if (CardNumber1.equals(22)) {
                        card2.setImageResource(R.drawable.c22)
                    } else if (CardNumber1.equals(23)) {
                        card2.setImageResource(R.drawable.c23)
                    } else if (CardNumber1.equals(24)) {
                        card2.setImageResource(R.drawable.c24)
                    } else if (CardNumber1.equals(25)) {
                        card2.setImageResource(R.drawable.c25)
                    } else if (CardNumber1.equals(26)) {
                        card2.setImageResource(R.drawable.c26)
                    } else if (CardNumber1.equals(27)) {
                        card2.setImageResource(R.drawable.c27)
                    } else if (CardNumber1.equals(28)) {
                        card2.setImageResource(R.drawable.c28)
                    } else if (CardNumber1.equals(29)) {
                        card2.setImageResource(R.drawable.c29)
                    } else {
                        card2.setImageResource(R.drawable.c30)
                    }
                } else if (cardSelected1.equals(3)) {
                    if (CardNumber1.equals(1)) {
                        card3.setImageResource(R.drawable.c1)
                    } else if (CardNumber1.equals(2)) {
                        card3.setImageResource(R.drawable.c2)
                    } else if (CardNumber1.equals(3)) {
                        card3.setImageResource(R.drawable.c3)
                    } else if (CardNumber1.equals(4)) {
                        card3.setImageResource(R.drawable.c4)
                    } else if (CardNumber1.equals(5)) {
                        card3.setImageResource(R.drawable.c5)
                    } else if (CardNumber1.equals(6)) {
                        card3.setImageResource(R.drawable.c6)
                    } else if (CardNumber1.equals(7)) {
                        card3.setImageResource(R.drawable.c7)
                    } else if (CardNumber1.equals(8)) {
                        card3.setImageResource(R.drawable.c8)
                    } else if (CardNumber1.equals(9)) {
                        card3.setImageResource(R.drawable.c9)
                    } else if (CardNumber1.equals(10)) {
                        card3.setImageResource(R.drawable.c10)
                    } else if (CardNumber1.equals(11)) {
                        card3.setImageResource(R.drawable.c11)
                    } else if (CardNumber1.equals(12)) {
                        card3.setImageResource(R.drawable.c12)
                    } else if (CardNumber1.equals(13)) {
                        card3.setImageResource(R.drawable.c13)
                    } else if (CardNumber1.equals(14)) {
                        card3.setImageResource(R.drawable.c14)
                    } else if (CardNumber1.equals(15)) {
                        card3.setImageResource(R.drawable.c15)
                    } else if (CardNumber1.equals(16)) {
                        card3.setImageResource(R.drawable.c16)
                    } else if (CardNumber1.equals(17)) {
                        card3.setImageResource(R.drawable.c17)
                    } else if (CardNumber1.equals(18)) {
                        card3.setImageResource(R.drawable.c18)
                    } else if (CardNumber1.equals(19)) {
                        card3.setImageResource(R.drawable.c19)
                    }  else if (CardNumber1.equals(20)) {
                        card3.setImageResource(R.drawable.c20)
                    } else if (CardNumber1.equals(21)) {
                        card3.setImageResource(R.drawable.c21)
                    } else if (CardNumber1.equals(22)) {
                        card3.setImageResource(R.drawable.c22)
                    } else if (CardNumber1.equals(23)) {
                        card3.setImageResource(R.drawable.c23)
                    } else if (CardNumber1.equals(24)) {
                        card3.setImageResource(R.drawable.c24)
                    } else if (CardNumber1.equals(25)) {
                        card3.setImageResource(R.drawable.c25)
                    } else if (CardNumber1.equals(26)) {
                        card3.setImageResource(R.drawable.c26)
                    } else if (CardNumber1.equals(27)) {
                        card3.setImageResource(R.drawable.c27)
                    } else if (CardNumber1.equals(28)) {
                        card3.setImageResource(R.drawable.c28)
                    } else if (CardNumber1.equals(29)) {
                        card3.setImageResource(R.drawable.c29)
                    } else {
                        card3.setImageResource(R.drawable.c30)
                    }
                } else if (cardSelected1.equals(4)) {
                    if (CardNumber1.equals(1)) {
                        card4.setImageResource(R.drawable.c1)
                    } else if (CardNumber1.equals(2)) {
                        card4.setImageResource(R.drawable.c2)
                    } else if (CardNumber1.equals(3)) {
                        card4.setImageResource(R.drawable.c3)
                    } else if (CardNumber1.equals(4)) {
                        card4.setImageResource(R.drawable.c4)
                    } else if (CardNumber1.equals(5)) {
                        card4.setImageResource(R.drawable.c5)
                    } else if (CardNumber1.equals(6)) {
                        card4.setImageResource(R.drawable.c6)
                    } else if (CardNumber1.equals(7)) {
                        card4.setImageResource(R.drawable.c7)
                    } else if (CardNumber1.equals(8)) {
                        card4.setImageResource(R.drawable.c8)
                    } else if (CardNumber1.equals(9)) {
                        card4.setImageResource(R.drawable.c9)
                    } else if (CardNumber1.equals(10)) {
                        card4.setImageResource(R.drawable.c10)
                    } else if (CardNumber1.equals(11)) {
                        card4.setImageResource(R.drawable.c11)
                    } else if (CardNumber1.equals(12)) {
                        card4.setImageResource(R.drawable.c12)
                    } else if (CardNumber1.equals(13)) {
                        card4.setImageResource(R.drawable.c13)
                    } else if (CardNumber1.equals(14)) {
                        card4.setImageResource(R.drawable.c14)
                    } else if (CardNumber1.equals(15)) {
                        card4.setImageResource(R.drawable.c15)
                    } else if (CardNumber1.equals(16)) {
                        card4.setImageResource(R.drawable.c16)
                    } else if (CardNumber1.equals(17)) {
                        card4.setImageResource(R.drawable.c17)
                    } else if (CardNumber1.equals(18)) {
                        card4.setImageResource(R.drawable.c18)
                    } else if (CardNumber1.equals(19)) {
                        card4.setImageResource(R.drawable.c19)
                    }  else if (CardNumber1.equals(20)) {
                        card4.setImageResource(R.drawable.c20)
                    } else if (CardNumber1.equals(21)) {
                        card4.setImageResource(R.drawable.c21)
                    } else if (CardNumber1.equals(22)) {
                        card4.setImageResource(R.drawable.c22)
                    } else if (CardNumber1.equals(23)) {
                        card4.setImageResource(R.drawable.c23)
                    } else if (CardNumber1.equals(24)) {
                        card4.setImageResource(R.drawable.c24)
                    } else if (CardNumber1.equals(25)) {
                        card4.setImageResource(R.drawable.c25)
                    } else if (CardNumber1.equals(26)) {
                        card4.setImageResource(R.drawable.c26)
                    } else if (CardNumber1.equals(27)) {
                        card4.setImageResource(R.drawable.c27)
                    } else if (CardNumber1.equals(28)) {
                        card4.setImageResource(R.drawable.c28)
                    } else if (CardNumber1.equals(29)) {
                        card4.setImageResource(R.drawable.c29)
                    } else {
                        card4.setImageResource(R.drawable.c30)
                    }
                } else {

                }

                if (cardSelected2.equals(1)) {
                    if (CardNumber2.equals(1)) {
                        card1.setImageResource(R.drawable.c1)
                    } else if (CardNumber2.equals(2)) {
                        card1.setImageResource(R.drawable.c2)
                    } else if (CardNumber2.equals(3)) {
                        card1.setImageResource(R.drawable.c3)
                    } else if (CardNumber2.equals(4)) {
                        card1.setImageResource(R.drawable.c4)
                    } else if (CardNumber2.equals(5)) {
                        card1.setImageResource(R.drawable.c5)
                    } else if (CardNumber2.equals(6)) {
                        card1.setImageResource(R.drawable.c6)
                    } else if (CardNumber2.equals(7)) {
                        card1.setImageResource(R.drawable.c7)
                    } else if (CardNumber2.equals(8)) {
                        card1.setImageResource(R.drawable.c8)
                    } else if (CardNumber2.equals(9)) {
                        card1.setImageResource(R.drawable.c9)
                    } else if (CardNumber2.equals(10)) {
                        card1.setImageResource(R.drawable.c10)
                    } else if (CardNumber2.equals(11)) {
                        card1.setImageResource(R.drawable.c11)
                    } else if (CardNumber2.equals(12)) {
                        card1.setImageResource(R.drawable.c12)
                    } else if (CardNumber2.equals(13)) {
                        card1.setImageResource(R.drawable.c13)
                    } else if (CardNumber2.equals(14)) {
                        card1.setImageResource(R.drawable.c14)
                    } else if (CardNumber2.equals(15)) {
                        card1.setImageResource(R.drawable.c15)
                    } else if (CardNumber2.equals(16)) {
                        card1.setImageResource(R.drawable.c16)
                    } else if (CardNumber2.equals(17)) {
                        card1.setImageResource(R.drawable.c17)
                    } else if (CardNumber2.equals(18)) {
                        card1.setImageResource(R.drawable.c18)
                    } else if (CardNumber2.equals(19)) {
                        card1.setImageResource(R.drawable.c19)
                    }  else if (CardNumber2.equals(20)) {
                        card1.setImageResource(R.drawable.c20)
                    } else if (CardNumber2.equals(21)) {
                        card1.setImageResource(R.drawable.c21)
                    } else if (CardNumber2.equals(22)) {
                        card1.setImageResource(R.drawable.c22)
                    } else if (CardNumber2.equals(23)) {
                        card1.setImageResource(R.drawable.c23)
                    } else if (CardNumber2.equals(24)) {
                        card1.setImageResource(R.drawable.c24)
                    } else if (CardNumber2.equals(25)) {
                        card1.setImageResource(R.drawable.c25)
                    } else if (CardNumber2.equals(26)) {
                        card1.setImageResource(R.drawable.c26)
                    } else if (CardNumber2.equals(27)) {
                        card1.setImageResource(R.drawable.c27)
                    } else if (CardNumber2.equals(28)) {
                        card1.setImageResource(R.drawable.c28)
                    } else if (CardNumber2.equals(29)) {
                        card1.setImageResource(R.drawable.c29)
                    } else {
                        card1.setImageResource(R.drawable.c30)
                    }
                } else if (cardSelected2.equals(2)) {
                    if (CardNumber2.equals(1)) {
                        card2.setImageResource(R.drawable.c1)
                    } else if (CardNumber2.equals(2)) {
                        card2.setImageResource(R.drawable.c2)
                    } else if (CardNumber2.equals(3)) {
                        card2.setImageResource(R.drawable.c3)
                    } else if (CardNumber2.equals(4)) {
                        card2.setImageResource(R.drawable.c4)
                    } else if (CardNumber2.equals(5)) {
                        card2.setImageResource(R.drawable.c5)
                    } else if (CardNumber2.equals(6)) {
                        card2.setImageResource(R.drawable.c6)
                    } else if (CardNumber2.equals(7)) {
                        card2.setImageResource(R.drawable.c7)
                    } else if (CardNumber2.equals(8)) {
                        card2.setImageResource(R.drawable.c8)
                    } else if (CardNumber2.equals(9)) {
                        card2.setImageResource(R.drawable.c9)
                    } else if (CardNumber2.equals(10)) {
                        card2.setImageResource(R.drawable.c10)
                    } else if (CardNumber2.equals(11)) {
                        card2.setImageResource(R.drawable.c11)
                    } else if (CardNumber2.equals(12)) {
                        card2.setImageResource(R.drawable.c12)
                    } else if (CardNumber2.equals(13)) {
                        card2.setImageResource(R.drawable.c13)
                    } else if (CardNumber2.equals(14)) {
                        card2.setImageResource(R.drawable.c14)
                    } else if (CardNumber2.equals(15)) {
                        card2.setImageResource(R.drawable.c15)
                    } else if (CardNumber2.equals(16)) {
                        card2.setImageResource(R.drawable.c16)
                    } else if (CardNumber2.equals(17)) {
                        card2.setImageResource(R.drawable.c17)
                    } else if (CardNumber2.equals(18)) {
                        card2.setImageResource(R.drawable.c18)
                    } else if (CardNumber2.equals(19)) {
                        card2.setImageResource(R.drawable.c19)
                    } else if (CardNumber2.equals(20)) {
                        card2.setImageResource(R.drawable.c20)
                    } else if (CardNumber2.equals(21)) {
                        card2.setImageResource(R.drawable.c21)
                    } else if (CardNumber2.equals(22)) {
                        card2.setImageResource(R.drawable.c22)
                    } else if (CardNumber2.equals(23)) {
                        card2.setImageResource(R.drawable.c23)
                    } else if (CardNumber2.equals(24)) {
                        card2.setImageResource(R.drawable.c24)
                    } else if (CardNumber2.equals(25)) {
                        card2.setImageResource(R.drawable.c25)
                    } else if (CardNumber2.equals(26)) {
                        card2.setImageResource(R.drawable.c26)
                    } else if (CardNumber2.equals(27)) {
                        card2.setImageResource(R.drawable.c27)
                    } else if (CardNumber2.equals(28)) {
                        card2.setImageResource(R.drawable.c28)
                    } else if (CardNumber2.equals(29)) {
                        card2.setImageResource(R.drawable.c29)
                    } else {
                        card2.setImageResource(R.drawable.c30)
                    }
                } else if (cardSelected2.equals(3)) {
                    if (CardNumber2.equals(1)) {
                        card3.setImageResource(R.drawable.c1)
                    } else if (CardNumber2.equals(2)) {
                        card3.setImageResource(R.drawable.c2)
                    } else if (CardNumber2.equals(3)) {
                        card3.setImageResource(R.drawable.c3)
                    } else if (CardNumber2.equals(4)) {
                        card3.setImageResource(R.drawable.c4)
                    } else if (CardNumber2.equals(5)) {
                        card3.setImageResource(R.drawable.c5)
                    } else if (CardNumber2.equals(6)) {
                        card3.setImageResource(R.drawable.c6)
                    } else if (CardNumber2.equals(7)) {
                        card3.setImageResource(R.drawable.c7)
                    } else if (CardNumber2.equals(8)) {
                        card3.setImageResource(R.drawable.c8)
                    } else if (CardNumber2.equals(9)) {
                        card3.setImageResource(R.drawable.c9)
                    } else if (CardNumber2.equals(10)) {
                        card3.setImageResource(R.drawable.c10)
                    }else if (CardNumber2.equals(11)) {
                        card3.setImageResource(R.drawable.c11)
                    } else if (CardNumber2.equals(12)) {
                        card3.setImageResource(R.drawable.c12)
                    } else if (CardNumber2.equals(13)) {
                        card3.setImageResource(R.drawable.c13)
                    } else if (CardNumber2.equals(14)) {
                        card3.setImageResource(R.drawable.c14)
                    } else if (CardNumber2.equals(15)) {
                        card3.setImageResource(R.drawable.c15)
                    } else if (CardNumber2.equals(16)) {
                        card3.setImageResource(R.drawable.c16)
                    } else if (CardNumber2.equals(17)) {
                        card3.setImageResource(R.drawable.c17)
                    } else if (CardNumber2.equals(18)) {
                        card3.setImageResource(R.drawable.c18)
                    } else if (CardNumber2.equals(19)) {
                        card3.setImageResource(R.drawable.c19)
                    }  else if (CardNumber2.equals(20)) {
                        card3.setImageResource(R.drawable.c20)
                    } else if (CardNumber2.equals(21)) {
                        card3.setImageResource(R.drawable.c21)
                    } else if (CardNumber2.equals(22)) {
                        card3.setImageResource(R.drawable.c22)
                    } else if (CardNumber2.equals(23)) {
                        card3.setImageResource(R.drawable.c23)
                    } else if (CardNumber2.equals(24)) {
                        card3.setImageResource(R.drawable.c24)
                    } else if (CardNumber2.equals(25)) {
                        card3.setImageResource(R.drawable.c25)
                    } else if (CardNumber2.equals(26)) {
                        card3.setImageResource(R.drawable.c26)
                    } else if (CardNumber2.equals(27)) {
                        card3.setImageResource(R.drawable.c27)
                    } else if (CardNumber2.equals(28)) {
                        card3.setImageResource(R.drawable.c28)
                    } else if (CardNumber2.equals(29)) {
                        card3.setImageResource(R.drawable.c29)
                    } else {
                        card3.setImageResource(R.drawable.c30)
                    }
                } else if (cardSelected2.equals(4)) {
                    if (CardNumber2.equals(1)) {
                        card4.setImageResource(R.drawable.c1)
                    } else if (CardNumber2.equals(2)) {
                        card4.setImageResource(R.drawable.c2)
                    } else if (CardNumber2.equals(3)) {
                        card4.setImageResource(R.drawable.c3)
                    } else if (CardNumber2.equals(4)) {
                        card4.setImageResource(R.drawable.c4)
                    } else if (CardNumber2.equals(5)) {
                        card4.setImageResource(R.drawable.c5)
                    } else if (CardNumber2.equals(6)) {
                        card4.setImageResource(R.drawable.c6)
                    } else if (CardNumber2.equals(7)) {
                        card4.setImageResource(R.drawable.c7)
                    } else if (CardNumber2.equals(8)) {
                        card4.setImageResource(R.drawable.c8)
                    } else if (CardNumber2.equals(9)) {
                        card4.setImageResource(R.drawable.c9)
                    } else if (CardNumber2.equals(10)) {
                        card4.setImageResource(R.drawable.c10)
                    }else if (CardNumber2.equals(11)) {
                        card4.setImageResource(R.drawable.c11)
                    } else if (CardNumber2.equals(12)) {
                        card4.setImageResource(R.drawable.c12)
                    } else if (CardNumber2.equals(13)) {
                        card4.setImageResource(R.drawable.c13)
                    } else if (CardNumber2.equals(14)) {
                        card4.setImageResource(R.drawable.c14)
                    } else if (CardNumber2.equals(15)) {
                        card4.setImageResource(R.drawable.c15)
                    } else if (CardNumber2.equals(16)) {
                        card4.setImageResource(R.drawable.c16)
                    } else if (CardNumber2.equals(17)) {
                        card4.setImageResource(R.drawable.c17)
                    } else if (CardNumber2.equals(18)) {
                        card4.setImageResource(R.drawable.c18)
                    } else if (CardNumber2.equals(19)) {
                        card4.setImageResource(R.drawable.c19)
                    } else if (CardNumber2.equals(20)) {
                        card4.setImageResource(R.drawable.c20)
                    } else if (CardNumber2.equals(21)) {
                        card4.setImageResource(R.drawable.c21)
                    } else if (CardNumber2.equals(22)) {
                        card4.setImageResource(R.drawable.c22)
                    } else if (CardNumber2.equals(23)) {
                        card4.setImageResource(R.drawable.c23)
                    } else if (CardNumber2.equals(24)) {
                        card4.setImageResource(R.drawable.c24)
                    } else if (CardNumber2.equals(25)) {
                        card4.setImageResource(R.drawable.c25)
                    } else if (CardNumber2.equals(26)) {
                        card4.setImageResource(R.drawable.c26)
                    } else if (CardNumber2.equals(27)) {
                        card4.setImageResource(R.drawable.c27)
                    } else if (CardNumber2.equals(28)) {
                        card4.setImageResource(R.drawable.c28)
                    } else if (CardNumber2.equals(29)) {
                        card4.setImageResource(R.drawable.c29)
                    } else {
                        card4.setImageResource(R.drawable.c30)
                    }
                } else {

                }
                        if(numround == 11){
                            submit.setText("Proceed to Final Round")
                        }else {
                            submit.setText("Proceed to Next Round")
                        }
//                Toast.makeText(this, "Round is Over!", Toast.LENGTH_LONG).show()
            }, 1000
            )
            }else if(cardSelected1 == 1){
                Toast.makeText(this, "Player One has already selected this Card!", Toast.LENGTH_LONG)
                    .show()
            }
            else {
                Toast.makeText(this, "Both Players have already selected!", Toast.LENGTH_LONG)
                    .show()
            }
        }
        card2.setOnClickListener {
            if (click.equals(0) && !player1) {
                player1 = true
                click = 1
//                Toast.makeText(this, "Player 1 has selected!", Toast.LENGTH_LONG).show()
                card2.setImageResource(R.drawable.p1_card_2)
                cardSelected1 = 2
                randInt()
            } else if (click.equals(1) && !player2 && cardSelected1 != 2) {
                player2 = true
                click = 2
//                Toast.makeText(this, "Player 2 has selected!", Toast.LENGTH_LONG).show()
                card2.setImageResource(R.drawable.p2_card_2)
                cardSelected2 = 2
                randInt1()
                Handler().postDelayed(
                    {
                        submit.visibility = View.VISIBLE
                if (cardSelected1.equals(1)) {
                    if (CardNumber1.equals(1)) {
                        card1.setImageResource(R.drawable.c1)
                    } else if (CardNumber1.equals(2)) {
                        card1.setImageResource(R.drawable.c2)
                    } else if (CardNumber1.equals(3)) {
                        card1.setImageResource(R.drawable.c3)
                    } else if (CardNumber1.equals(4)) {
                        card1.setImageResource(R.drawable.c4)
                    } else if (CardNumber1.equals(5)) {
                        card1.setImageResource(R.drawable.c5)
                    } else if (CardNumber1.equals(6)) {
                        card1.setImageResource(R.drawable.c6)
                    } else if (CardNumber1.equals(7)) {
                        card1.setImageResource(R.drawable.c7)
                    } else if (CardNumber1.equals(8)) {
                        card1.setImageResource(R.drawable.c8)
                    } else if (CardNumber1.equals(9)) {
                        card1.setImageResource(R.drawable.c9)
                    } else if (CardNumber1.equals(10)) {
                        card1.setImageResource(R.drawable.c10)
                    } else if (CardNumber1.equals(11)) {
                        card1.setImageResource(R.drawable.c11)
                    } else if (CardNumber1.equals(12)) {
                        card1.setImageResource(R.drawable.c12)
                    } else if (CardNumber1.equals(13)) {
                        card1.setImageResource(R.drawable.c13)
                    } else if (CardNumber1.equals(14)) {
                        card1.setImageResource(R.drawable.c14)
                    } else if (CardNumber1.equals(15)) {
                        card1.setImageResource(R.drawable.c15)
                    } else if (CardNumber1.equals(16)) {
                        card1.setImageResource(R.drawable.c16)
                    } else if (CardNumber1.equals(17)) {
                        card1.setImageResource(R.drawable.c17)
                    } else if (CardNumber1.equals(18)) {
                        card1.setImageResource(R.drawable.c18)
                    } else if (CardNumber1.equals(19)) {
                        card1.setImageResource(R.drawable.c19)
                    }  else if (CardNumber1.equals(20)) {
                        card1.setImageResource(R.drawable.c20)
                    } else if (CardNumber1.equals(21)) {
                        card1.setImageResource(R.drawable.c21)
                    } else if (CardNumber1.equals(22)) {
                        card1.setImageResource(R.drawable.c22)
                    } else if (CardNumber1.equals(23)) {
                        card1.setImageResource(R.drawable.c23)
                    } else if (CardNumber1.equals(24)) {
                        card1.setImageResource(R.drawable.c24)
                    } else if (CardNumber1.equals(25)) {
                        card1.setImageResource(R.drawable.c25)
                    } else if (CardNumber1.equals(26)) {
                        card1.setImageResource(R.drawable.c26)
                    } else if (CardNumber1.equals(27)) {
                        card1.setImageResource(R.drawable.c27)
                    } else if (CardNumber1.equals(28)) {
                        card1.setImageResource(R.drawable.c28)
                    } else if (CardNumber1.equals(29)) {
                        card1.setImageResource(R.drawable.c29)
                    } else {
                        card1.setImageResource(R.drawable.c30)
                    }
                } else if (cardSelected1.equals(2)) {
                    if (CardNumber1.equals(1)) {
                        card2.setImageResource(R.drawable.c1)
                    } else if (CardNumber1.equals(2)) {
                        card2.setImageResource(R.drawable.c2)
                    } else if (CardNumber1.equals(3)) {
                        card2.setImageResource(R.drawable.c3)
                    } else if (CardNumber1.equals(4)) {
                        card2.setImageResource(R.drawable.c4)
                    } else if (CardNumber1.equals(5)) {
                        card2.setImageResource(R.drawable.c5)
                    } else if (CardNumber1.equals(6)) {
                        card2.setImageResource(R.drawable.c6)
                    } else if (CardNumber1.equals(7)) {
                        card2.setImageResource(R.drawable.c7)
                    } else if (CardNumber1.equals(8)) {
                        card2.setImageResource(R.drawable.c8)
                    } else if (CardNumber1.equals(9)) {
                        card2.setImageResource(R.drawable.c9)
                    } else if (CardNumber1.equals(10)) {
                        card2.setImageResource(R.drawable.c10)
                    } else if (CardNumber1.equals(11)) {
                        card2.setImageResource(R.drawable.c11)
                    } else if (CardNumber1.equals(12)) {
                        card2.setImageResource(R.drawable.c12)
                    } else if (CardNumber1.equals(13)) {
                        card2.setImageResource(R.drawable.c13)
                    } else if (CardNumber1.equals(14)) {
                        card2.setImageResource(R.drawable.c14)
                    } else if (CardNumber1.equals(15)) {
                        card2.setImageResource(R.drawable.c15)
                    } else if (CardNumber1.equals(16)) {
                        card2.setImageResource(R.drawable.c16)
                    } else if (CardNumber1.equals(17)) {
                        card2.setImageResource(R.drawable.c17)
                    } else if (CardNumber1.equals(18)) {
                        card2.setImageResource(R.drawable.c18)
                    } else if (CardNumber1.equals(19)) {
                        card2.setImageResource(R.drawable.c19)
                    }  else if (CardNumber1.equals(20)) {
                        card2.setImageResource(R.drawable.c20)
                    } else if (CardNumber1.equals(21)) {
                        card2.setImageResource(R.drawable.c21)
                    } else if (CardNumber1.equals(22)) {
                        card2.setImageResource(R.drawable.c22)
                    } else if (CardNumber1.equals(23)) {
                        card2.setImageResource(R.drawable.c23)
                    } else if (CardNumber1.equals(24)) {
                        card2.setImageResource(R.drawable.c24)
                    } else if (CardNumber1.equals(25)) {
                        card2.setImageResource(R.drawable.c25)
                    } else if (CardNumber1.equals(26)) {
                        card2.setImageResource(R.drawable.c26)
                    } else if (CardNumber1.equals(27)) {
                        card2.setImageResource(R.drawable.c27)
                    } else if (CardNumber1.equals(28)) {
                        card2.setImageResource(R.drawable.c28)
                    } else if (CardNumber1.equals(29)) {
                        card2.setImageResource(R.drawable.c29)
                    } else {
                        card2.setImageResource(R.drawable.c30)
                    }
                } else if (cardSelected1.equals(3)) {
                    if (CardNumber1.equals(1)) {
                        card3.setImageResource(R.drawable.c1)
                    } else if (CardNumber1.equals(2)) {
                        card3.setImageResource(R.drawable.c2)
                    } else if (CardNumber1.equals(3)) {
                        card3.setImageResource(R.drawable.c3)
                    } else if (CardNumber1.equals(4)) {
                        card3.setImageResource(R.drawable.c4)
                    } else if (CardNumber1.equals(5)) {
                        card3.setImageResource(R.drawable.c5)
                    } else if (CardNumber1.equals(6)) {
                        card3.setImageResource(R.drawable.c6)
                    } else if (CardNumber1.equals(7)) {
                        card3.setImageResource(R.drawable.c7)
                    } else if (CardNumber1.equals(8)) {
                        card3.setImageResource(R.drawable.c8)
                    } else if (CardNumber1.equals(9)) {
                        card3.setImageResource(R.drawable.c9)
                    } else if (CardNumber1.equals(10)) {
                        card3.setImageResource(R.drawable.c10)
                    } else if (CardNumber1.equals(11)) {
                        card3.setImageResource(R.drawable.c11)
                    } else if (CardNumber1.equals(12)) {
                        card3.setImageResource(R.drawable.c12)
                    } else if (CardNumber1.equals(13)) {
                        card3.setImageResource(R.drawable.c13)
                    } else if (CardNumber1.equals(14)) {
                        card3.setImageResource(R.drawable.c14)
                    } else if (CardNumber1.equals(15)) {
                        card3.setImageResource(R.drawable.c15)
                    } else if (CardNumber1.equals(16)) {
                        card3.setImageResource(R.drawable.c16)
                    } else if (CardNumber1.equals(17)) {
                        card3.setImageResource(R.drawable.c17)
                    } else if (CardNumber1.equals(18)) {
                        card3.setImageResource(R.drawable.c18)
                    } else if (CardNumber1.equals(19)) {
                        card3.setImageResource(R.drawable.c19)
                    }  else if (CardNumber1.equals(20)) {
                        card3.setImageResource(R.drawable.c20)
                    } else if (CardNumber1.equals(21)) {
                        card3.setImageResource(R.drawable.c21)
                    } else if (CardNumber1.equals(22)) {
                        card3.setImageResource(R.drawable.c22)
                    } else if (CardNumber1.equals(23)) {
                        card3.setImageResource(R.drawable.c23)
                    } else if (CardNumber1.equals(24)) {
                        card3.setImageResource(R.drawable.c24)
                    } else if (CardNumber1.equals(25)) {
                        card3.setImageResource(R.drawable.c25)
                    } else if (CardNumber1.equals(26)) {
                        card3.setImageResource(R.drawable.c26)
                    } else if (CardNumber1.equals(27)) {
                        card3.setImageResource(R.drawable.c27)
                    } else if (CardNumber1.equals(28)) {
                        card3.setImageResource(R.drawable.c28)
                    } else if (CardNumber1.equals(29)) {
                        card3.setImageResource(R.drawable.c29)
                    } else {
                        card3.setImageResource(R.drawable.c30)
                    }
                } else if (cardSelected1.equals(4)) {
                    if (CardNumber1.equals(1)) {
                        card4.setImageResource(R.drawable.c1)
                    } else if (CardNumber1.equals(2)) {
                        card4.setImageResource(R.drawable.c2)
                    } else if (CardNumber1.equals(3)) {
                        card4.setImageResource(R.drawable.c3)
                    } else if (CardNumber1.equals(4)) {
                        card4.setImageResource(R.drawable.c4)
                    } else if (CardNumber1.equals(5)) {
                        card4.setImageResource(R.drawable.c5)
                    } else if (CardNumber1.equals(6)) {
                        card4.setImageResource(R.drawable.c6)
                    } else if (CardNumber1.equals(7)) {
                        card4.setImageResource(R.drawable.c7)
                    } else if (CardNumber1.equals(8)) {
                        card4.setImageResource(R.drawable.c8)
                    } else if (CardNumber1.equals(9)) {
                        card4.setImageResource(R.drawable.c9)
                    } else if (CardNumber1.equals(10)) {
                        card4.setImageResource(R.drawable.c10)
                    } else if (CardNumber1.equals(11)) {
                        card4.setImageResource(R.drawable.c11)
                    } else if (CardNumber1.equals(12)) {
                        card4.setImageResource(R.drawable.c12)
                    } else if (CardNumber1.equals(13)) {
                        card4.setImageResource(R.drawable.c13)
                    } else if (CardNumber1.equals(14)) {
                        card4.setImageResource(R.drawable.c14)
                    } else if (CardNumber1.equals(15)) {
                        card4.setImageResource(R.drawable.c15)
                    } else if (CardNumber1.equals(16)) {
                        card4.setImageResource(R.drawable.c16)
                    } else if (CardNumber1.equals(17)) {
                        card4.setImageResource(R.drawable.c17)
                    } else if (CardNumber1.equals(18)) {
                        card4.setImageResource(R.drawable.c18)
                    } else if (CardNumber1.equals(19)) {
                        card4.setImageResource(R.drawable.c19)
                    }  else if (CardNumber1.equals(20)) {
                        card4.setImageResource(R.drawable.c20)
                    } else if (CardNumber1.equals(21)) {
                        card4.setImageResource(R.drawable.c21)
                    } else if (CardNumber1.equals(22)) {
                        card4.setImageResource(R.drawable.c22)
                    } else if (CardNumber1.equals(23)) {
                        card4.setImageResource(R.drawable.c23)
                    } else if (CardNumber1.equals(24)) {
                        card4.setImageResource(R.drawable.c24)
                    } else if (CardNumber1.equals(25)) {
                        card4.setImageResource(R.drawable.c25)
                    } else if (CardNumber1.equals(26)) {
                        card4.setImageResource(R.drawable.c26)
                    } else if (CardNumber1.equals(27)) {
                        card4.setImageResource(R.drawable.c27)
                    } else if (CardNumber1.equals(28)) {
                        card4.setImageResource(R.drawable.c28)
                    } else if (CardNumber1.equals(29)) {
                        card4.setImageResource(R.drawable.c29)
                    } else {
                        card4.setImageResource(R.drawable.c30)
                    }
                } else {

                }

                if (cardSelected2.equals(1)) {
                    if (CardNumber2.equals(1)) {
                        card1.setImageResource(R.drawable.c1)
                    } else if (CardNumber2.equals(2)) {
                        card1.setImageResource(R.drawable.c2)
                    } else if (CardNumber2.equals(3)) {
                        card1.setImageResource(R.drawable.c3)
                    } else if (CardNumber2.equals(4)) {
                        card1.setImageResource(R.drawable.c4)
                    } else if (CardNumber2.equals(5)) {
                        card1.setImageResource(R.drawable.c5)
                    } else if (CardNumber2.equals(6)) {
                        card1.setImageResource(R.drawable.c6)
                    } else if (CardNumber2.equals(7)) {
                        card1.setImageResource(R.drawable.c7)
                    } else if (CardNumber2.equals(8)) {
                        card1.setImageResource(R.drawable.c8)
                    } else if (CardNumber2.equals(9)) {
                        card1.setImageResource(R.drawable.c9)
                    } else if (CardNumber2.equals(10)) {
                        card1.setImageResource(R.drawable.c10)
                    } else if (CardNumber2.equals(11)) {
                        card1.setImageResource(R.drawable.c11)
                    } else if (CardNumber2.equals(12)) {
                        card1.setImageResource(R.drawable.c12)
                    } else if (CardNumber2.equals(13)) {
                        card1.setImageResource(R.drawable.c13)
                    } else if (CardNumber2.equals(14)) {
                        card1.setImageResource(R.drawable.c14)
                    } else if (CardNumber2.equals(15)) {
                        card1.setImageResource(R.drawable.c15)
                    } else if (CardNumber2.equals(16)) {
                        card1.setImageResource(R.drawable.c16)
                    } else if (CardNumber2.equals(17)) {
                        card1.setImageResource(R.drawable.c17)
                    } else if (CardNumber2.equals(18)) {
                        card1.setImageResource(R.drawable.c18)
                    } else if (CardNumber2.equals(19)) {
                        card1.setImageResource(R.drawable.c19)
                    }  else if (CardNumber2.equals(20)) {
                        card1.setImageResource(R.drawable.c20)
                    } else if (CardNumber2.equals(21)) {
                        card1.setImageResource(R.drawable.c21)
                    } else if (CardNumber2.equals(22)) {
                        card1.setImageResource(R.drawable.c22)
                    } else if (CardNumber2.equals(23)) {
                        card1.setImageResource(R.drawable.c23)
                    } else if (CardNumber2.equals(24)) {
                        card1.setImageResource(R.drawable.c24)
                    } else if (CardNumber2.equals(25)) {
                        card1.setImageResource(R.drawable.c25)
                    } else if (CardNumber2.equals(26)) {
                        card1.setImageResource(R.drawable.c26)
                    } else if (CardNumber2.equals(27)) {
                        card1.setImageResource(R.drawable.c27)
                    } else if (CardNumber2.equals(28)) {
                        card1.setImageResource(R.drawable.c28)
                    } else if (CardNumber2.equals(29)) {
                        card1.setImageResource(R.drawable.c29)
                    } else {
                        card1.setImageResource(R.drawable.c30)
                    }
                } else if (cardSelected2.equals(2)) {
                    if (CardNumber2.equals(1)) {
                        card2.setImageResource(R.drawable.c1)
                    } else if (CardNumber2.equals(2)) {
                        card2.setImageResource(R.drawable.c2)
                    } else if (CardNumber2.equals(3)) {
                        card2.setImageResource(R.drawable.c3)
                    } else if (CardNumber2.equals(4)) {
                        card2.setImageResource(R.drawable.c4)
                    } else if (CardNumber2.equals(5)) {
                        card2.setImageResource(R.drawable.c5)
                    } else if (CardNumber2.equals(6)) {
                        card2.setImageResource(R.drawable.c6)
                    } else if (CardNumber2.equals(7)) {
                        card2.setImageResource(R.drawable.c7)
                    } else if (CardNumber2.equals(8)) {
                        card2.setImageResource(R.drawable.c8)
                    } else if (CardNumber2.equals(9)) {
                        card2.setImageResource(R.drawable.c9)
                    } else if (CardNumber2.equals(10)) {
                        card2.setImageResource(R.drawable.c10)
                    } else if (CardNumber2.equals(11)) {
                        card2.setImageResource(R.drawable.c11)
                    } else if (CardNumber2.equals(12)) {
                        card2.setImageResource(R.drawable.c12)
                    } else if (CardNumber2.equals(13)) {
                        card2.setImageResource(R.drawable.c13)
                    } else if (CardNumber2.equals(14)) {
                        card2.setImageResource(R.drawable.c14)
                    } else if (CardNumber2.equals(15)) {
                        card2.setImageResource(R.drawable.c15)
                    } else if (CardNumber2.equals(16)) {
                        card2.setImageResource(R.drawable.c16)
                    } else if (CardNumber2.equals(17)) {
                        card2.setImageResource(R.drawable.c17)
                    } else if (CardNumber2.equals(18)) {
                        card2.setImageResource(R.drawable.c18)
                    } else if (CardNumber2.equals(19)) {
                        card2.setImageResource(R.drawable.c19)
                    } else if (CardNumber2.equals(20)) {
                        card2.setImageResource(R.drawable.c20)
                    } else if (CardNumber2.equals(21)) {
                        card2.setImageResource(R.drawable.c21)
                    } else if (CardNumber2.equals(22)) {
                        card2.setImageResource(R.drawable.c22)
                    } else if (CardNumber2.equals(23)) {
                        card2.setImageResource(R.drawable.c23)
                    } else if (CardNumber2.equals(24)) {
                        card2.setImageResource(R.drawable.c24)
                    } else if (CardNumber2.equals(25)) {
                        card2.setImageResource(R.drawable.c25)
                    } else if (CardNumber2.equals(26)) {
                        card2.setImageResource(R.drawable.c26)
                    } else if (CardNumber2.equals(27)) {
                        card2.setImageResource(R.drawable.c27)
                    } else if (CardNumber2.equals(28)) {
                        card2.setImageResource(R.drawable.c28)
                    } else if (CardNumber2.equals(29)) {
                        card2.setImageResource(R.drawable.c29)
                    } else {
                        card2.setImageResource(R.drawable.c30)
                    }
                } else if (cardSelected2.equals(3)) {
                    if (CardNumber2.equals(1)) {
                        card3.setImageResource(R.drawable.c1)
                    } else if (CardNumber2.equals(2)) {
                        card3.setImageResource(R.drawable.c2)
                    } else if (CardNumber2.equals(3)) {
                        card3.setImageResource(R.drawable.c3)
                    } else if (CardNumber2.equals(4)) {
                        card3.setImageResource(R.drawable.c4)
                    } else if (CardNumber2.equals(5)) {
                        card3.setImageResource(R.drawable.c5)
                    } else if (CardNumber2.equals(6)) {
                        card3.setImageResource(R.drawable.c6)
                    } else if (CardNumber2.equals(7)) {
                        card3.setImageResource(R.drawable.c7)
                    } else if (CardNumber2.equals(8)) {
                        card3.setImageResource(R.drawable.c8)
                    } else if (CardNumber2.equals(9)) {
                        card3.setImageResource(R.drawable.c9)
                    } else if (CardNumber2.equals(10)) {
                        card3.setImageResource(R.drawable.c10)
                    }else if (CardNumber2.equals(11)) {
                        card3.setImageResource(R.drawable.c11)
                    } else if (CardNumber2.equals(12)) {
                        card3.setImageResource(R.drawable.c12)
                    } else if (CardNumber2.equals(13)) {
                        card3.setImageResource(R.drawable.c13)
                    } else if (CardNumber2.equals(14)) {
                        card3.setImageResource(R.drawable.c14)
                    } else if (CardNumber2.equals(15)) {
                        card3.setImageResource(R.drawable.c15)
                    } else if (CardNumber2.equals(16)) {
                        card3.setImageResource(R.drawable.c16)
                    } else if (CardNumber2.equals(17)) {
                        card3.setImageResource(R.drawable.c17)
                    } else if (CardNumber2.equals(18)) {
                        card3.setImageResource(R.drawable.c18)
                    } else if (CardNumber2.equals(19)) {
                        card3.setImageResource(R.drawable.c19)
                    }  else if (CardNumber2.equals(20)) {
                        card3.setImageResource(R.drawable.c20)
                    } else if (CardNumber2.equals(21)) {
                        card3.setImageResource(R.drawable.c21)
                    } else if (CardNumber2.equals(22)) {
                        card3.setImageResource(R.drawable.c22)
                    } else if (CardNumber2.equals(23)) {
                        card3.setImageResource(R.drawable.c23)
                    } else if (CardNumber2.equals(24)) {
                        card3.setImageResource(R.drawable.c24)
                    } else if (CardNumber2.equals(25)) {
                        card3.setImageResource(R.drawable.c25)
                    } else if (CardNumber2.equals(26)) {
                        card3.setImageResource(R.drawable.c26)
                    } else if (CardNumber2.equals(27)) {
                        card3.setImageResource(R.drawable.c27)
                    } else if (CardNumber2.equals(28)) {
                        card3.setImageResource(R.drawable.c28)
                    } else if (CardNumber2.equals(29)) {
                        card3.setImageResource(R.drawable.c29)
                    } else {
                        card3.setImageResource(R.drawable.c30)
                    }
                } else if (cardSelected2.equals(4)) {
                    if (CardNumber2.equals(1)) {
                        card4.setImageResource(R.drawable.c1)
                    } else if (CardNumber2.equals(2)) {
                        card4.setImageResource(R.drawable.c2)
                    } else if (CardNumber2.equals(3)) {
                        card4.setImageResource(R.drawable.c3)
                    } else if (CardNumber2.equals(4)) {
                        card4.setImageResource(R.drawable.c4)
                    } else if (CardNumber2.equals(5)) {
                        card4.setImageResource(R.drawable.c5)
                    } else if (CardNumber2.equals(6)) {
                        card4.setImageResource(R.drawable.c6)
                    } else if (CardNumber2.equals(7)) {
                        card4.setImageResource(R.drawable.c7)
                    } else if (CardNumber2.equals(8)) {
                        card4.setImageResource(R.drawable.c8)
                    } else if (CardNumber2.equals(9)) {
                        card4.setImageResource(R.drawable.c9)
                    } else if (CardNumber2.equals(10)) {
                        card4.setImageResource(R.drawable.c10)
                    }else if (CardNumber2.equals(11)) {
                        card4.setImageResource(R.drawable.c11)
                    } else if (CardNumber2.equals(12)) {
                        card4.setImageResource(R.drawable.c12)
                    } else if (CardNumber2.equals(13)) {
                        card4.setImageResource(R.drawable.c13)
                    } else if (CardNumber2.equals(14)) {
                        card4.setImageResource(R.drawable.c14)
                    } else if (CardNumber2.equals(15)) {
                        card4.setImageResource(R.drawable.c15)
                    } else if (CardNumber2.equals(16)) {
                        card4.setImageResource(R.drawable.c16)
                    } else if (CardNumber2.equals(17)) {
                        card4.setImageResource(R.drawable.c17)
                    } else if (CardNumber2.equals(18)) {
                        card4.setImageResource(R.drawable.c18)
                    } else if (CardNumber2.equals(19)) {
                        card4.setImageResource(R.drawable.c19)
                    } else if (CardNumber2.equals(20)) {
                        card4.setImageResource(R.drawable.c20)
                    } else if (CardNumber2.equals(21)) {
                        card4.setImageResource(R.drawable.c21)
                    } else if (CardNumber2.equals(22)) {
                        card4.setImageResource(R.drawable.c22)
                    } else if (CardNumber2.equals(23)) {
                        card4.setImageResource(R.drawable.c23)
                    } else if (CardNumber2.equals(24)) {
                        card4.setImageResource(R.drawable.c24)
                    } else if (CardNumber2.equals(25)) {
                        card4.setImageResource(R.drawable.c25)
                    } else if (CardNumber2.equals(26)) {
                        card4.setImageResource(R.drawable.c26)
                    } else if (CardNumber2.equals(27)) {
                        card4.setImageResource(R.drawable.c27)
                    } else if (CardNumber2.equals(28)) {
                        card4.setImageResource(R.drawable.c28)
                    } else if (CardNumber2.equals(29)) {
                        card4.setImageResource(R.drawable.c29)
                    } else {
                        card4.setImageResource(R.drawable.c30)
                    }
                } else {

                }
                        if(numround == 11){
                            submit.setText("Proceed to Final Round")
                        }else {
                            submit.setText("Proceed to Next Round")
                        }
//                Toast.makeText(this, "Round is Over!", Toast.LENGTH_LONG).show()
            },1000
            )
            }else if(cardSelected1 == 2){
                Toast.makeText(this, "Player One has already selected this Card!", Toast.LENGTH_LONG)
                    .show()
            } else {
                Toast.makeText(this, "Both Players have already selected!", Toast.LENGTH_LONG)
                    .show()
            }
        }
        card3.setOnClickListener {
            if (click.equals(0) && !player1) {
                player1 = true
                click = 1
//                Toast.makeText(this, "Player 1 has selected!", Toast.LENGTH_LONG).show()
                card3.setImageResource(R.drawable.p1_card_3)
                cardSelected1 = 3
                randInt()
            } else if (click.equals(1) && !player2 && cardSelected1 != 3) {
                player2 = true
                click = 2
//                Toast.makeText(this, "Player 2 has selected!", Toast.LENGTH_LONG).show()
                card3.setImageResource(R.drawable.p2_card_3)
                cardSelected2 = 3
                randInt1()
                Handler().postDelayed(
                    {
                        submit.visibility = View.VISIBLE
                if (cardSelected1.equals(1)) {
                    if (CardNumber1.equals(1)) {
                        card1.setImageResource(R.drawable.c1)
                    } else if (CardNumber1.equals(2)) {
                        card1.setImageResource(R.drawable.c2)
                    } else if (CardNumber1.equals(3)) {
                        card1.setImageResource(R.drawable.c3)
                    } else if (CardNumber1.equals(4)) {
                        card1.setImageResource(R.drawable.c4)
                    } else if (CardNumber1.equals(5)) {
                        card1.setImageResource(R.drawable.c5)
                    } else if (CardNumber1.equals(6)) {
                        card1.setImageResource(R.drawable.c6)
                    } else if (CardNumber1.equals(7)) {
                        card1.setImageResource(R.drawable.c7)
                    } else if (CardNumber1.equals(8)) {
                        card1.setImageResource(R.drawable.c8)
                    } else if (CardNumber1.equals(9)) {
                        card1.setImageResource(R.drawable.c9)
                    } else if (CardNumber1.equals(10)) {
                        card1.setImageResource(R.drawable.c10)
                    } else if (CardNumber1.equals(11)) {
                        card1.setImageResource(R.drawable.c11)
                    } else if (CardNumber1.equals(12)) {
                        card1.setImageResource(R.drawable.c12)
                    } else if (CardNumber1.equals(13)) {
                        card1.setImageResource(R.drawable.c13)
                    } else if (CardNumber1.equals(14)) {
                        card1.setImageResource(R.drawable.c14)
                    } else if (CardNumber1.equals(15)) {
                        card1.setImageResource(R.drawable.c15)
                    } else if (CardNumber1.equals(16)) {
                        card1.setImageResource(R.drawable.c16)
                    } else if (CardNumber1.equals(17)) {
                        card1.setImageResource(R.drawable.c17)
                    } else if (CardNumber1.equals(18)) {
                        card1.setImageResource(R.drawable.c18)
                    } else if (CardNumber1.equals(19)) {
                        card1.setImageResource(R.drawable.c19)
                    }  else if (CardNumber1.equals(20)) {
                        card1.setImageResource(R.drawable.c20)
                    } else if (CardNumber1.equals(21)) {
                        card1.setImageResource(R.drawable.c21)
                    } else if (CardNumber1.equals(22)) {
                        card1.setImageResource(R.drawable.c22)
                    } else if (CardNumber1.equals(23)) {
                        card1.setImageResource(R.drawable.c23)
                    } else if (CardNumber1.equals(24)) {
                        card1.setImageResource(R.drawable.c24)
                    } else if (CardNumber1.equals(25)) {
                        card1.setImageResource(R.drawable.c25)
                    } else if (CardNumber1.equals(26)) {
                        card1.setImageResource(R.drawable.c26)
                    } else if (CardNumber1.equals(27)) {
                        card1.setImageResource(R.drawable.c27)
                    } else if (CardNumber1.equals(28)) {
                        card1.setImageResource(R.drawable.c28)
                    } else if (CardNumber1.equals(29)) {
                        card1.setImageResource(R.drawable.c29)
                    } else {
                        card1.setImageResource(R.drawable.c30)
                    }
                } else if (cardSelected1.equals(2)) {
                    if (CardNumber1.equals(1)) {
                        card2.setImageResource(R.drawable.c1)
                    } else if (CardNumber1.equals(2)) {
                        card2.setImageResource(R.drawable.c2)
                    } else if (CardNumber1.equals(3)) {
                        card2.setImageResource(R.drawable.c3)
                    } else if (CardNumber1.equals(4)) {
                        card2.setImageResource(R.drawable.c4)
                    } else if (CardNumber1.equals(5)) {
                        card2.setImageResource(R.drawable.c5)
                    } else if (CardNumber1.equals(6)) {
                        card2.setImageResource(R.drawable.c6)
                    } else if (CardNumber1.equals(7)) {
                        card2.setImageResource(R.drawable.c7)
                    } else if (CardNumber1.equals(8)) {
                        card2.setImageResource(R.drawable.c8)
                    } else if (CardNumber1.equals(9)) {
                        card2.setImageResource(R.drawable.c9)
                    } else if (CardNumber1.equals(10)) {
                        card2.setImageResource(R.drawable.c10)
                    } else if (CardNumber1.equals(11)) {
                        card2.setImageResource(R.drawable.c11)
                    } else if (CardNumber1.equals(12)) {
                        card2.setImageResource(R.drawable.c12)
                    } else if (CardNumber1.equals(13)) {
                        card2.setImageResource(R.drawable.c13)
                    } else if (CardNumber1.equals(14)) {
                        card2.setImageResource(R.drawable.c14)
                    } else if (CardNumber1.equals(15)) {
                        card2.setImageResource(R.drawable.c15)
                    } else if (CardNumber1.equals(16)) {
                        card2.setImageResource(R.drawable.c16)
                    } else if (CardNumber1.equals(17)) {
                        card2.setImageResource(R.drawable.c17)
                    } else if (CardNumber1.equals(18)) {
                        card2.setImageResource(R.drawable.c18)
                    } else if (CardNumber1.equals(19)) {
                        card2.setImageResource(R.drawable.c19)
                    }  else if (CardNumber1.equals(20)) {
                        card2.setImageResource(R.drawable.c20)
                    } else if (CardNumber1.equals(21)) {
                        card2.setImageResource(R.drawable.c21)
                    } else if (CardNumber1.equals(22)) {
                        card2.setImageResource(R.drawable.c22)
                    } else if (CardNumber1.equals(23)) {
                        card2.setImageResource(R.drawable.c23)
                    } else if (CardNumber1.equals(24)) {
                        card2.setImageResource(R.drawable.c24)
                    } else if (CardNumber1.equals(25)) {
                        card2.setImageResource(R.drawable.c25)
                    } else if (CardNumber1.equals(26)) {
                        card2.setImageResource(R.drawable.c26)
                    } else if (CardNumber1.equals(27)) {
                        card2.setImageResource(R.drawable.c27)
                    } else if (CardNumber1.equals(28)) {
                        card2.setImageResource(R.drawable.c28)
                    } else if (CardNumber1.equals(29)) {
                        card2.setImageResource(R.drawable.c29)
                    } else {
                        card2.setImageResource(R.drawable.c30)
                    }
                } else if (cardSelected1.equals(3)) {
                    if (CardNumber1.equals(1)) {
                        card3.setImageResource(R.drawable.c1)
                    } else if (CardNumber1.equals(2)) {
                        card3.setImageResource(R.drawable.c2)
                    } else if (CardNumber1.equals(3)) {
                        card3.setImageResource(R.drawable.c3)
                    } else if (CardNumber1.equals(4)) {
                        card3.setImageResource(R.drawable.c4)
                    } else if (CardNumber1.equals(5)) {
                        card3.setImageResource(R.drawable.c5)
                    } else if (CardNumber1.equals(6)) {
                        card3.setImageResource(R.drawable.c6)
                    } else if (CardNumber1.equals(7)) {
                        card3.setImageResource(R.drawable.c7)
                    } else if (CardNumber1.equals(8)) {
                        card3.setImageResource(R.drawable.c8)
                    } else if (CardNumber1.equals(9)) {
                        card3.setImageResource(R.drawable.c9)
                    } else if (CardNumber1.equals(10)) {
                        card3.setImageResource(R.drawable.c10)
                    } else if (CardNumber1.equals(11)) {
                        card3.setImageResource(R.drawable.c11)
                    } else if (CardNumber1.equals(12)) {
                        card3.setImageResource(R.drawable.c12)
                    } else if (CardNumber1.equals(13)) {
                        card3.setImageResource(R.drawable.c13)
                    } else if (CardNumber1.equals(14)) {
                        card3.setImageResource(R.drawable.c14)
                    } else if (CardNumber1.equals(15)) {
                        card3.setImageResource(R.drawable.c15)
                    } else if (CardNumber1.equals(16)) {
                        card3.setImageResource(R.drawable.c16)
                    } else if (CardNumber1.equals(17)) {
                        card3.setImageResource(R.drawable.c17)
                    } else if (CardNumber1.equals(18)) {
                        card3.setImageResource(R.drawable.c18)
                    } else if (CardNumber1.equals(19)) {
                        card3.setImageResource(R.drawable.c19)
                    }  else if (CardNumber1.equals(20)) {
                        card3.setImageResource(R.drawable.c20)
                    } else if (CardNumber1.equals(21)) {
                        card3.setImageResource(R.drawable.c21)
                    } else if (CardNumber1.equals(22)) {
                        card3.setImageResource(R.drawable.c22)
                    } else if (CardNumber1.equals(23)) {
                        card3.setImageResource(R.drawable.c23)
                    } else if (CardNumber1.equals(24)) {
                        card3.setImageResource(R.drawable.c24)
                    } else if (CardNumber1.equals(25)) {
                        card3.setImageResource(R.drawable.c25)
                    } else if (CardNumber1.equals(26)) {
                        card3.setImageResource(R.drawable.c26)
                    } else if (CardNumber1.equals(27)) {
                        card3.setImageResource(R.drawable.c27)
                    } else if (CardNumber1.equals(28)) {
                        card3.setImageResource(R.drawable.c28)
                    } else if (CardNumber1.equals(29)) {
                        card3.setImageResource(R.drawable.c29)
                    } else {
                        card3.setImageResource(R.drawable.c30)
                    }
                } else if (cardSelected1.equals(4)) {
                    if (CardNumber1.equals(1)) {
                        card4.setImageResource(R.drawable.c1)
                    } else if (CardNumber1.equals(2)) {
                        card4.setImageResource(R.drawable.c2)
                    } else if (CardNumber1.equals(3)) {
                        card4.setImageResource(R.drawable.c3)
                    } else if (CardNumber1.equals(4)) {
                        card4.setImageResource(R.drawable.c4)
                    } else if (CardNumber1.equals(5)) {
                        card4.setImageResource(R.drawable.c5)
                    } else if (CardNumber1.equals(6)) {
                        card4.setImageResource(R.drawable.c6)
                    } else if (CardNumber1.equals(7)) {
                        card4.setImageResource(R.drawable.c7)
                    } else if (CardNumber1.equals(8)) {
                        card4.setImageResource(R.drawable.c8)
                    } else if (CardNumber1.equals(9)) {
                        card4.setImageResource(R.drawable.c9)
                    } else if (CardNumber1.equals(10)) {
                        card4.setImageResource(R.drawable.c10)
                    } else if (CardNumber1.equals(11)) {
                        card4.setImageResource(R.drawable.c11)
                    } else if (CardNumber1.equals(12)) {
                        card4.setImageResource(R.drawable.c12)
                    } else if (CardNumber1.equals(13)) {
                        card4.setImageResource(R.drawable.c13)
                    } else if (CardNumber1.equals(14)) {
                        card4.setImageResource(R.drawable.c14)
                    } else if (CardNumber1.equals(15)) {
                        card4.setImageResource(R.drawable.c15)
                    } else if (CardNumber1.equals(16)) {
                        card4.setImageResource(R.drawable.c16)
                    } else if (CardNumber1.equals(17)) {
                        card4.setImageResource(R.drawable.c17)
                    } else if (CardNumber1.equals(18)) {
                        card4.setImageResource(R.drawable.c18)
                    } else if (CardNumber1.equals(19)) {
                        card4.setImageResource(R.drawable.c19)
                    }  else if (CardNumber1.equals(20)) {
                        card4.setImageResource(R.drawable.c20)
                    } else if (CardNumber1.equals(21)) {
                        card4.setImageResource(R.drawable.c21)
                    } else if (CardNumber1.equals(22)) {
                        card4.setImageResource(R.drawable.c22)
                    } else if (CardNumber1.equals(23)) {
                        card4.setImageResource(R.drawable.c23)
                    } else if (CardNumber1.equals(24)) {
                        card4.setImageResource(R.drawable.c24)
                    } else if (CardNumber1.equals(25)) {
                        card4.setImageResource(R.drawable.c25)
                    } else if (CardNumber1.equals(26)) {
                        card4.setImageResource(R.drawable.c26)
                    } else if (CardNumber1.equals(27)) {
                        card4.setImageResource(R.drawable.c27)
                    } else if (CardNumber1.equals(28)) {
                        card4.setImageResource(R.drawable.c28)
                    } else if (CardNumber1.equals(29)) {
                        card4.setImageResource(R.drawable.c29)
                    } else {
                        card4.setImageResource(R.drawable.c30)
                    }
                } else {

                }

                if (cardSelected2.equals(1)) {
                    if (CardNumber2.equals(1)) {
                        card1.setImageResource(R.drawable.c1)
                    } else if (CardNumber2.equals(2)) {
                        card1.setImageResource(R.drawable.c2)
                    } else if (CardNumber2.equals(3)) {
                        card1.setImageResource(R.drawable.c3)
                    } else if (CardNumber2.equals(4)) {
                        card1.setImageResource(R.drawable.c4)
                    } else if (CardNumber2.equals(5)) {
                        card1.setImageResource(R.drawable.c5)
                    } else if (CardNumber2.equals(6)) {
                        card1.setImageResource(R.drawable.c6)
                    } else if (CardNumber2.equals(7)) {
                        card1.setImageResource(R.drawable.c7)
                    } else if (CardNumber2.equals(8)) {
                        card1.setImageResource(R.drawable.c8)
                    } else if (CardNumber2.equals(9)) {
                        card1.setImageResource(R.drawable.c9)
                    } else if (CardNumber2.equals(10)) {
                        card1.setImageResource(R.drawable.c10)
                    } else if (CardNumber2.equals(11)) {
                        card1.setImageResource(R.drawable.c11)
                    } else if (CardNumber2.equals(12)) {
                        card1.setImageResource(R.drawable.c12)
                    } else if (CardNumber2.equals(13)) {
                        card1.setImageResource(R.drawable.c13)
                    } else if (CardNumber2.equals(14)) {
                        card1.setImageResource(R.drawable.c14)
                    } else if (CardNumber2.equals(15)) {
                        card1.setImageResource(R.drawable.c15)
                    } else if (CardNumber2.equals(16)) {
                        card1.setImageResource(R.drawable.c16)
                    } else if (CardNumber2.equals(17)) {
                        card1.setImageResource(R.drawable.c17)
                    } else if (CardNumber2.equals(18)) {
                        card1.setImageResource(R.drawable.c18)
                    } else if (CardNumber2.equals(19)) {
                        card1.setImageResource(R.drawable.c19)
                    }  else if (CardNumber2.equals(20)) {
                        card1.setImageResource(R.drawable.c20)
                    } else if (CardNumber2.equals(21)) {
                        card1.setImageResource(R.drawable.c21)
                    } else if (CardNumber2.equals(22)) {
                        card1.setImageResource(R.drawable.c22)
                    } else if (CardNumber2.equals(23)) {
                        card1.setImageResource(R.drawable.c23)
                    } else if (CardNumber2.equals(24)) {
                        card1.setImageResource(R.drawable.c24)
                    } else if (CardNumber2.equals(25)) {
                        card1.setImageResource(R.drawable.c25)
                    } else if (CardNumber2.equals(26)) {
                        card1.setImageResource(R.drawable.c26)
                    } else if (CardNumber2.equals(27)) {
                        card1.setImageResource(R.drawable.c27)
                    } else if (CardNumber2.equals(28)) {
                        card1.setImageResource(R.drawable.c28)
                    } else if (CardNumber2.equals(29)) {
                        card1.setImageResource(R.drawable.c29)
                    } else {
                        card1.setImageResource(R.drawable.c30)
                    }
                } else if (cardSelected2.equals(2)) {
                    if (CardNumber2.equals(1)) {
                        card2.setImageResource(R.drawable.c1)
                    } else if (CardNumber2.equals(2)) {
                        card2.setImageResource(R.drawable.c2)
                    } else if (CardNumber2.equals(3)) {
                        card2.setImageResource(R.drawable.c3)
                    } else if (CardNumber2.equals(4)) {
                        card2.setImageResource(R.drawable.c4)
                    } else if (CardNumber2.equals(5)) {
                        card2.setImageResource(R.drawable.c5)
                    } else if (CardNumber2.equals(6)) {
                        card2.setImageResource(R.drawable.c6)
                    } else if (CardNumber2.equals(7)) {
                        card2.setImageResource(R.drawable.c7)
                    } else if (CardNumber2.equals(8)) {
                        card2.setImageResource(R.drawable.c8)
                    } else if (CardNumber2.equals(9)) {
                        card2.setImageResource(R.drawable.c9)
                    } else if (CardNumber2.equals(10)) {
                        card2.setImageResource(R.drawable.c10)
                    } else if (CardNumber2.equals(11)) {
                        card2.setImageResource(R.drawable.c11)
                    } else if (CardNumber2.equals(12)) {
                        card2.setImageResource(R.drawable.c12)
                    } else if (CardNumber2.equals(13)) {
                        card2.setImageResource(R.drawable.c13)
                    } else if (CardNumber2.equals(14)) {
                        card2.setImageResource(R.drawable.c14)
                    } else if (CardNumber2.equals(15)) {
                        card2.setImageResource(R.drawable.c15)
                    } else if (CardNumber2.equals(16)) {
                        card2.setImageResource(R.drawable.c16)
                    } else if (CardNumber2.equals(17)) {
                        card2.setImageResource(R.drawable.c17)
                    } else if (CardNumber2.equals(18)) {
                        card2.setImageResource(R.drawable.c18)
                    } else if (CardNumber2.equals(19)) {
                        card2.setImageResource(R.drawable.c19)
                    } else if (CardNumber2.equals(20)) {
                        card2.setImageResource(R.drawable.c20)
                    } else if (CardNumber2.equals(21)) {
                        card2.setImageResource(R.drawable.c21)
                    } else if (CardNumber2.equals(22)) {
                        card2.setImageResource(R.drawable.c22)
                    } else if (CardNumber2.equals(23)) {
                        card2.setImageResource(R.drawable.c23)
                    } else if (CardNumber2.equals(24)) {
                        card2.setImageResource(R.drawable.c24)
                    } else if (CardNumber2.equals(25)) {
                        card2.setImageResource(R.drawable.c25)
                    } else if (CardNumber2.equals(26)) {
                        card2.setImageResource(R.drawable.c26)
                    } else if (CardNumber2.equals(27)) {
                        card2.setImageResource(R.drawable.c27)
                    } else if (CardNumber2.equals(28)) {
                        card2.setImageResource(R.drawable.c28)
                    } else if (CardNumber2.equals(29)) {
                        card2.setImageResource(R.drawable.c29)
                    } else {
                        card2.setImageResource(R.drawable.c30)
                    }
                } else if (cardSelected2.equals(3)) {
                    if (CardNumber2.equals(1)) {
                        card3.setImageResource(R.drawable.c1)
                    } else if (CardNumber2.equals(2)) {
                        card3.setImageResource(R.drawable.c2)
                    } else if (CardNumber2.equals(3)) {
                        card3.setImageResource(R.drawable.c3)
                    } else if (CardNumber2.equals(4)) {
                        card3.setImageResource(R.drawable.c4)
                    } else if (CardNumber2.equals(5)) {
                        card3.setImageResource(R.drawable.c5)
                    } else if (CardNumber2.equals(6)) {
                        card3.setImageResource(R.drawable.c6)
                    } else if (CardNumber2.equals(7)) {
                        card3.setImageResource(R.drawable.c7)
                    } else if (CardNumber2.equals(8)) {
                        card3.setImageResource(R.drawable.c8)
                    } else if (CardNumber2.equals(9)) {
                        card3.setImageResource(R.drawable.c9)
                    } else if (CardNumber2.equals(10)) {
                        card3.setImageResource(R.drawable.c10)
                    }else if (CardNumber2.equals(11)) {
                        card3.setImageResource(R.drawable.c11)
                    } else if (CardNumber2.equals(12)) {
                        card3.setImageResource(R.drawable.c12)
                    } else if (CardNumber2.equals(13)) {
                        card3.setImageResource(R.drawable.c13)
                    } else if (CardNumber2.equals(14)) {
                        card3.setImageResource(R.drawable.c14)
                    } else if (CardNumber2.equals(15)) {
                        card3.setImageResource(R.drawable.c15)
                    } else if (CardNumber2.equals(16)) {
                        card3.setImageResource(R.drawable.c16)
                    } else if (CardNumber2.equals(17)) {
                        card3.setImageResource(R.drawable.c17)
                    } else if (CardNumber2.equals(18)) {
                        card3.setImageResource(R.drawable.c18)
                    } else if (CardNumber2.equals(19)) {
                        card3.setImageResource(R.drawable.c19)
                    }  else if (CardNumber2.equals(20)) {
                        card3.setImageResource(R.drawable.c20)
                    } else if (CardNumber2.equals(21)) {
                        card3.setImageResource(R.drawable.c21)
                    } else if (CardNumber2.equals(22)) {
                        card3.setImageResource(R.drawable.c22)
                    } else if (CardNumber2.equals(23)) {
                        card3.setImageResource(R.drawable.c23)
                    } else if (CardNumber2.equals(24)) {
                        card3.setImageResource(R.drawable.c24)
                    } else if (CardNumber2.equals(25)) {
                        card3.setImageResource(R.drawable.c25)
                    } else if (CardNumber2.equals(26)) {
                        card3.setImageResource(R.drawable.c26)
                    } else if (CardNumber2.equals(27)) {
                        card3.setImageResource(R.drawable.c27)
                    } else if (CardNumber2.equals(28)) {
                        card3.setImageResource(R.drawable.c28)
                    } else if (CardNumber2.equals(29)) {
                        card3.setImageResource(R.drawable.c29)
                    } else {
                        card3.setImageResource(R.drawable.c30)
                    }
                } else if (cardSelected2.equals(4)) {
                    if (CardNumber2.equals(1)) {
                        card4.setImageResource(R.drawable.c1)
                    } else if (CardNumber2.equals(2)) {
                        card4.setImageResource(R.drawable.c2)
                    } else if (CardNumber2.equals(3)) {
                        card4.setImageResource(R.drawable.c3)
                    } else if (CardNumber2.equals(4)) {
                        card4.setImageResource(R.drawable.c4)
                    } else if (CardNumber2.equals(5)) {
                        card4.setImageResource(R.drawable.c5)
                    } else if (CardNumber2.equals(6)) {
                        card4.setImageResource(R.drawable.c6)
                    } else if (CardNumber2.equals(7)) {
                        card4.setImageResource(R.drawable.c7)
                    } else if (CardNumber2.equals(8)) {
                        card4.setImageResource(R.drawable.c8)
                    } else if (CardNumber2.equals(9)) {
                        card4.setImageResource(R.drawable.c9)
                    } else if (CardNumber2.equals(10)) {
                        card4.setImageResource(R.drawable.c10)
                    }else if (CardNumber2.equals(11)) {
                        card4.setImageResource(R.drawable.c11)
                    } else if (CardNumber2.equals(12)) {
                        card4.setImageResource(R.drawable.c12)
                    } else if (CardNumber2.equals(13)) {
                        card4.setImageResource(R.drawable.c13)
                    } else if (CardNumber2.equals(14)) {
                        card4.setImageResource(R.drawable.c14)
                    } else if (CardNumber2.equals(15)) {
                        card4.setImageResource(R.drawable.c15)
                    } else if (CardNumber2.equals(16)) {
                        card4.setImageResource(R.drawable.c16)
                    } else if (CardNumber2.equals(17)) {
                        card4.setImageResource(R.drawable.c17)
                    } else if (CardNumber2.equals(18)) {
                        card4.setImageResource(R.drawable.c18)
                    } else if (CardNumber2.equals(19)) {
                        card4.setImageResource(R.drawable.c19)
                    } else if (CardNumber2.equals(20)) {
                        card4.setImageResource(R.drawable.c20)
                    } else if (CardNumber2.equals(21)) {
                        card4.setImageResource(R.drawable.c21)
                    } else if (CardNumber2.equals(22)) {
                        card4.setImageResource(R.drawable.c22)
                    } else if (CardNumber2.equals(23)) {
                        card4.setImageResource(R.drawable.c23)
                    } else if (CardNumber2.equals(24)) {
                        card4.setImageResource(R.drawable.c24)
                    } else if (CardNumber2.equals(25)) {
                        card4.setImageResource(R.drawable.c25)
                    } else if (CardNumber2.equals(26)) {
                        card4.setImageResource(R.drawable.c26)
                    } else if (CardNumber2.equals(27)) {
                        card4.setImageResource(R.drawable.c27)
                    } else if (CardNumber2.equals(28)) {
                        card4.setImageResource(R.drawable.c28)
                    } else if (CardNumber2.equals(29)) {
                        card4.setImageResource(R.drawable.c29)
                    } else {
                        card4.setImageResource(R.drawable.c30)
                    }
                } else {

                }
                        if(numround == 11){
                            submit.setText("Proceed to Final Round")
                        }else {
                            submit.setText("Proceed to Next Round")
                        }
//                Toast.makeText(this, "Round is Over!", Toast.LENGTH_LONG).show()
            }, 1000
            )
            }else if(cardSelected1 == 3){
                Toast.makeText(this, "Player One has already selected this Card!", Toast.LENGTH_LONG)
                    .show()
            } else {
                Toast.makeText(this, "Both Players have already selected!", Toast.LENGTH_LONG)
                    .show()
            }
        }
        card4.setOnClickListener {
            if (click.equals(0) && !player1) {
                player1 = true
                click = 1
//                Toast.makeText(this, "Player 1 has selected!", Toast.LENGTH_LONG).show()
                card4.setImageResource(R.drawable.p1_card_4)
                cardSelected1 = 4
                randInt()
            } else if (click.equals(1) && !player2 && cardSelected1 != 4) {
                player2 = true
                click = 2
//                Toast.makeText(this, "Player 2 has selected!", Toast.LENGTH_LONG).show()
                card4.setImageResource(R.drawable.p2_card_4)
                cardSelected2 = 4
                randInt1()
                Handler().postDelayed(
                    {

                        submit.visibility = View.VISIBLE
                if (cardSelected1.equals(1)) {
                    if (CardNumber1.equals(1)) {
                        card1.setImageResource(R.drawable.c1)
                    } else if (CardNumber1.equals(2)) {
                        card1.setImageResource(R.drawable.c2)
                    } else if (CardNumber1.equals(3)) {
                        card1.setImageResource(R.drawable.c3)
                    } else if (CardNumber1.equals(4)) {
                        card1.setImageResource(R.drawable.c4)
                    } else if (CardNumber1.equals(5)) {
                        card1.setImageResource(R.drawable.c5)
                    } else if (CardNumber1.equals(6)) {
                        card1.setImageResource(R.drawable.c6)
                    } else if (CardNumber1.equals(7)) {
                        card1.setImageResource(R.drawable.c7)
                    } else if (CardNumber1.equals(8)) {
                        card1.setImageResource(R.drawable.c8)
                    } else if (CardNumber1.equals(9)) {
                        card1.setImageResource(R.drawable.c9)
                    } else if (CardNumber1.equals(10)) {
                        card1.setImageResource(R.drawable.c10)
                    } else if (CardNumber1.equals(11)) {
                        card1.setImageResource(R.drawable.c11)
                    } else if (CardNumber1.equals(12)) {
                        card1.setImageResource(R.drawable.c12)
                    } else if (CardNumber1.equals(13)) {
                        card1.setImageResource(R.drawable.c13)
                    } else if (CardNumber1.equals(14)) {
                        card1.setImageResource(R.drawable.c14)
                    } else if (CardNumber1.equals(15)) {
                        card1.setImageResource(R.drawable.c15)
                    } else if (CardNumber1.equals(16)) {
                        card1.setImageResource(R.drawable.c16)
                    } else if (CardNumber1.equals(17)) {
                        card1.setImageResource(R.drawable.c17)
                    } else if (CardNumber1.equals(18)) {
                        card1.setImageResource(R.drawable.c18)
                    } else if (CardNumber1.equals(19)) {
                        card1.setImageResource(R.drawable.c19)
                    }  else if (CardNumber1.equals(20)) {
                        card1.setImageResource(R.drawable.c20)
                    } else if (CardNumber1.equals(21)) {
                        card1.setImageResource(R.drawable.c21)
                    } else if (CardNumber1.equals(22)) {
                        card1.setImageResource(R.drawable.c22)
                    } else if (CardNumber1.equals(23)) {
                        card1.setImageResource(R.drawable.c23)
                    } else if (CardNumber1.equals(24)) {
                        card1.setImageResource(R.drawable.c24)
                    } else if (CardNumber1.equals(25)) {
                        card1.setImageResource(R.drawable.c25)
                    } else if (CardNumber1.equals(26)) {
                        card1.setImageResource(R.drawable.c26)
                    } else if (CardNumber1.equals(27)) {
                        card1.setImageResource(R.drawable.c27)
                    } else if (CardNumber1.equals(28)) {
                        card1.setImageResource(R.drawable.c28)
                    } else if (CardNumber1.equals(29)) {
                        card1.setImageResource(R.drawable.c29)
                    } else {
                        card1.setImageResource(R.drawable.c30)
                    }
                } else if (cardSelected1.equals(2)) {
                    if (CardNumber1.equals(1)) {
                        card2.setImageResource(R.drawable.c1)
                    } else if (CardNumber1.equals(2)) {
                        card2.setImageResource(R.drawable.c2)
                    } else if (CardNumber1.equals(3)) {
                        card2.setImageResource(R.drawable.c3)
                    } else if (CardNumber1.equals(4)) {
                        card2.setImageResource(R.drawable.c4)
                    } else if (CardNumber1.equals(5)) {
                        card2.setImageResource(R.drawable.c5)
                    } else if (CardNumber1.equals(6)) {
                        card2.setImageResource(R.drawable.c6)
                    } else if (CardNumber1.equals(7)) {
                        card2.setImageResource(R.drawable.c7)
                    } else if (CardNumber1.equals(8)) {
                        card2.setImageResource(R.drawable.c8)
                    } else if (CardNumber1.equals(9)) {
                        card2.setImageResource(R.drawable.c9)
                    } else if (CardNumber1.equals(10)) {
                        card2.setImageResource(R.drawable.c10)
                    } else if (CardNumber1.equals(11)) {
                        card2.setImageResource(R.drawable.c11)
                    } else if (CardNumber1.equals(12)) {
                        card2.setImageResource(R.drawable.c12)
                    } else if (CardNumber1.equals(13)) {
                        card2.setImageResource(R.drawable.c13)
                    } else if (CardNumber1.equals(14)) {
                        card2.setImageResource(R.drawable.c14)
                    } else if (CardNumber1.equals(15)) {
                        card2.setImageResource(R.drawable.c15)
                    } else if (CardNumber1.equals(16)) {
                        card2.setImageResource(R.drawable.c16)
                    } else if (CardNumber1.equals(17)) {
                        card2.setImageResource(R.drawable.c17)
                    } else if (CardNumber1.equals(18)) {
                        card2.setImageResource(R.drawable.c18)
                    } else if (CardNumber1.equals(19)) {
                        card2.setImageResource(R.drawable.c19)
                    }  else if (CardNumber1.equals(20)) {
                        card2.setImageResource(R.drawable.c20)
                    } else if (CardNumber1.equals(21)) {
                        card2.setImageResource(R.drawable.c21)
                    } else if (CardNumber1.equals(22)) {
                        card2.setImageResource(R.drawable.c22)
                    } else if (CardNumber1.equals(23)) {
                        card2.setImageResource(R.drawable.c23)
                    } else if (CardNumber1.equals(24)) {
                        card2.setImageResource(R.drawable.c24)
                    } else if (CardNumber1.equals(25)) {
                        card2.setImageResource(R.drawable.c25)
                    } else if (CardNumber1.equals(26)) {
                        card2.setImageResource(R.drawable.c26)
                    } else if (CardNumber1.equals(27)) {
                        card2.setImageResource(R.drawable.c27)
                    } else if (CardNumber1.equals(28)) {
                        card2.setImageResource(R.drawable.c28)
                    } else if (CardNumber1.equals(29)) {
                        card2.setImageResource(R.drawable.c29)
                    } else {
                        card2.setImageResource(R.drawable.c30)
                    }
                } else if (cardSelected1.equals(3)) {
                    if (CardNumber1.equals(1)) {
                        card3.setImageResource(R.drawable.c1)
                    } else if (CardNumber1.equals(2)) {
                        card3.setImageResource(R.drawable.c2)
                    } else if (CardNumber1.equals(3)) {
                        card3.setImageResource(R.drawable.c3)
                    } else if (CardNumber1.equals(4)) {
                        card3.setImageResource(R.drawable.c4)
                    } else if (CardNumber1.equals(5)) {
                        card3.setImageResource(R.drawable.c5)
                    } else if (CardNumber1.equals(6)) {
                        card3.setImageResource(R.drawable.c6)
                    } else if (CardNumber1.equals(7)) {
                        card3.setImageResource(R.drawable.c7)
                    } else if (CardNumber1.equals(8)) {
                        card3.setImageResource(R.drawable.c8)
                    } else if (CardNumber1.equals(9)) {
                        card3.setImageResource(R.drawable.c9)
                    } else if (CardNumber1.equals(10)) {
                        card3.setImageResource(R.drawable.c10)
                    } else if (CardNumber1.equals(11)) {
                        card3.setImageResource(R.drawable.c11)
                    } else if (CardNumber1.equals(12)) {
                        card3.setImageResource(R.drawable.c12)
                    } else if (CardNumber1.equals(13)) {
                        card3.setImageResource(R.drawable.c13)
                    } else if (CardNumber1.equals(14)) {
                        card3.setImageResource(R.drawable.c14)
                    } else if (CardNumber1.equals(15)) {
                        card3.setImageResource(R.drawable.c15)
                    } else if (CardNumber1.equals(16)) {
                        card3.setImageResource(R.drawable.c16)
                    } else if (CardNumber1.equals(17)) {
                        card3.setImageResource(R.drawable.c17)
                    } else if (CardNumber1.equals(18)) {
                        card3.setImageResource(R.drawable.c18)
                    } else if (CardNumber1.equals(19)) {
                        card3.setImageResource(R.drawable.c19)
                    }  else if (CardNumber1.equals(20)) {
                        card3.setImageResource(R.drawable.c20)
                    } else if (CardNumber1.equals(21)) {
                        card3.setImageResource(R.drawable.c21)
                    } else if (CardNumber1.equals(22)) {
                        card3.setImageResource(R.drawable.c22)
                    } else if (CardNumber1.equals(23)) {
                        card3.setImageResource(R.drawable.c23)
                    } else if (CardNumber1.equals(24)) {
                        card3.setImageResource(R.drawable.c24)
                    } else if (CardNumber1.equals(25)) {
                        card3.setImageResource(R.drawable.c25)
                    } else if (CardNumber1.equals(26)) {
                        card3.setImageResource(R.drawable.c26)
                    } else if (CardNumber1.equals(27)) {
                        card3.setImageResource(R.drawable.c27)
                    } else if (CardNumber1.equals(28)) {
                        card3.setImageResource(R.drawable.c28)
                    } else if (CardNumber1.equals(29)) {
                        card3.setImageResource(R.drawable.c29)
                    } else {
                        card3.setImageResource(R.drawable.c30)
                    }
                } else if (cardSelected1.equals(4)) {
                    if (CardNumber1.equals(1)) {
                        card4.setImageResource(R.drawable.c1)
                    } else if (CardNumber1.equals(2)) {
                        card4.setImageResource(R.drawable.c2)
                    } else if (CardNumber1.equals(3)) {
                        card4.setImageResource(R.drawable.c3)
                    } else if (CardNumber1.equals(4)) {
                        card4.setImageResource(R.drawable.c4)
                    } else if (CardNumber1.equals(5)) {
                        card4.setImageResource(R.drawable.c5)
                    } else if (CardNumber1.equals(6)) {
                        card4.setImageResource(R.drawable.c6)
                    } else if (CardNumber1.equals(7)) {
                        card4.setImageResource(R.drawable.c7)
                    } else if (CardNumber1.equals(8)) {
                        card4.setImageResource(R.drawable.c8)
                    } else if (CardNumber1.equals(9)) {
                        card4.setImageResource(R.drawable.c9)
                    } else if (CardNumber1.equals(10)) {
                        card4.setImageResource(R.drawable.c10)
                    } else if (CardNumber1.equals(11)) {
                        card4.setImageResource(R.drawable.c11)
                    } else if (CardNumber1.equals(12)) {
                        card4.setImageResource(R.drawable.c12)
                    } else if (CardNumber1.equals(13)) {
                        card4.setImageResource(R.drawable.c13)
                    } else if (CardNumber1.equals(14)) {
                        card4.setImageResource(R.drawable.c14)
                    } else if (CardNumber1.equals(15)) {
                        card4.setImageResource(R.drawable.c15)
                    } else if (CardNumber1.equals(16)) {
                        card4.setImageResource(R.drawable.c16)
                    } else if (CardNumber1.equals(17)) {
                        card4.setImageResource(R.drawable.c17)
                    } else if (CardNumber1.equals(18)) {
                        card4.setImageResource(R.drawable.c18)
                    } else if (CardNumber1.equals(19)) {
                        card4.setImageResource(R.drawable.c19)
                    }  else if (CardNumber1.equals(20)) {
                        card4.setImageResource(R.drawable.c20)
                    } else if (CardNumber1.equals(21)) {
                        card4.setImageResource(R.drawable.c21)
                    } else if (CardNumber1.equals(22)) {
                        card4.setImageResource(R.drawable.c22)
                    } else if (CardNumber1.equals(23)) {
                        card4.setImageResource(R.drawable.c23)
                    } else if (CardNumber1.equals(24)) {
                        card4.setImageResource(R.drawable.c24)
                    } else if (CardNumber1.equals(25)) {
                        card4.setImageResource(R.drawable.c25)
                    } else if (CardNumber1.equals(26)) {
                        card4.setImageResource(R.drawable.c26)
                    } else if (CardNumber1.equals(27)) {
                        card4.setImageResource(R.drawable.c27)
                    } else if (CardNumber1.equals(28)) {
                        card4.setImageResource(R.drawable.c28)
                    } else if (CardNumber1.equals(29)) {
                        card4.setImageResource(R.drawable.c29)
                    } else {
                        card4.setImageResource(R.drawable.c30)
                    }
                } else {

                }

                if (cardSelected2.equals(1)) {
                    if (CardNumber2.equals(1)) {
                        card1.setImageResource(R.drawable.c1)
                    } else if (CardNumber2.equals(2)) {
                        card1.setImageResource(R.drawable.c2)
                    } else if (CardNumber2.equals(3)) {
                        card1.setImageResource(R.drawable.c3)
                    } else if (CardNumber2.equals(4)) {
                        card1.setImageResource(R.drawable.c4)
                    } else if (CardNumber2.equals(5)) {
                        card1.setImageResource(R.drawable.c5)
                    } else if (CardNumber2.equals(6)) {
                        card1.setImageResource(R.drawable.c6)
                    } else if (CardNumber2.equals(7)) {
                        card1.setImageResource(R.drawable.c7)
                    } else if (CardNumber2.equals(8)) {
                        card1.setImageResource(R.drawable.c8)
                    } else if (CardNumber2.equals(9)) {
                        card1.setImageResource(R.drawable.c9)
                    } else if (CardNumber2.equals(10)) {
                        card1.setImageResource(R.drawable.c10)
                    } else if (CardNumber2.equals(11)) {
                        card1.setImageResource(R.drawable.c11)
                    } else if (CardNumber2.equals(12)) {
                        card1.setImageResource(R.drawable.c12)
                    } else if (CardNumber2.equals(13)) {
                        card1.setImageResource(R.drawable.c13)
                    } else if (CardNumber2.equals(14)) {
                        card1.setImageResource(R.drawable.c14)
                    } else if (CardNumber2.equals(15)) {
                        card1.setImageResource(R.drawable.c15)
                    } else if (CardNumber2.equals(16)) {
                        card1.setImageResource(R.drawable.c16)
                    } else if (CardNumber2.equals(17)) {
                        card1.setImageResource(R.drawable.c17)
                    } else if (CardNumber2.equals(18)) {
                        card1.setImageResource(R.drawable.c18)
                    } else if (CardNumber2.equals(19)) {
                        card1.setImageResource(R.drawable.c19)
                    }  else if (CardNumber2.equals(20)) {
                        card1.setImageResource(R.drawable.c20)
                    } else if (CardNumber2.equals(21)) {
                        card1.setImageResource(R.drawable.c21)
                    } else if (CardNumber2.equals(22)) {
                        card1.setImageResource(R.drawable.c22)
                    } else if (CardNumber2.equals(23)) {
                        card1.setImageResource(R.drawable.c23)
                    } else if (CardNumber2.equals(24)) {
                        card1.setImageResource(R.drawable.c24)
                    } else if (CardNumber2.equals(25)) {
                        card1.setImageResource(R.drawable.c25)
                    } else if (CardNumber2.equals(26)) {
                        card1.setImageResource(R.drawable.c26)
                    } else if (CardNumber2.equals(27)) {
                        card1.setImageResource(R.drawable.c27)
                    } else if (CardNumber2.equals(28)) {
                        card1.setImageResource(R.drawable.c28)
                    } else if (CardNumber2.equals(29)) {
                        card1.setImageResource(R.drawable.c29)
                    } else {
                        card1.setImageResource(R.drawable.c30)
                    }
                } else if (cardSelected2.equals(2)) {
                    if (CardNumber2.equals(1)) {
                        card2.setImageResource(R.drawable.c1)
                    } else if (CardNumber2.equals(2)) {
                        card2.setImageResource(R.drawable.c2)
                    } else if (CardNumber2.equals(3)) {
                        card2.setImageResource(R.drawable.c3)
                    } else if (CardNumber2.equals(4)) {
                        card2.setImageResource(R.drawable.c4)
                    } else if (CardNumber2.equals(5)) {
                        card2.setImageResource(R.drawable.c5)
                    } else if (CardNumber2.equals(6)) {
                        card2.setImageResource(R.drawable.c6)
                    } else if (CardNumber2.equals(7)) {
                        card2.setImageResource(R.drawable.c7)
                    } else if (CardNumber2.equals(8)) {
                        card2.setImageResource(R.drawable.c8)
                    } else if (CardNumber2.equals(9)) {
                        card2.setImageResource(R.drawable.c9)
                    } else if (CardNumber2.equals(10)) {
                        card2.setImageResource(R.drawable.c10)
                    } else if (CardNumber2.equals(11)) {
                        card2.setImageResource(R.drawable.c11)
                    } else if (CardNumber2.equals(12)) {
                        card2.setImageResource(R.drawable.c12)
                    } else if (CardNumber2.equals(13)) {
                        card2.setImageResource(R.drawable.c13)
                    } else if (CardNumber2.equals(14)) {
                        card2.setImageResource(R.drawable.c14)
                    } else if (CardNumber2.equals(15)) {
                        card2.setImageResource(R.drawable.c15)
                    } else if (CardNumber2.equals(16)) {
                        card2.setImageResource(R.drawable.c16)
                    } else if (CardNumber2.equals(17)) {
                        card2.setImageResource(R.drawable.c17)
                    } else if (CardNumber2.equals(18)) {
                        card2.setImageResource(R.drawable.c18)
                    } else if (CardNumber2.equals(19)) {
                        card2.setImageResource(R.drawable.c19)
                    } else if (CardNumber2.equals(20)) {
                        card2.setImageResource(R.drawable.c20)
                    } else if (CardNumber2.equals(21)) {
                        card2.setImageResource(R.drawable.c21)
                    } else if (CardNumber2.equals(22)) {
                        card2.setImageResource(R.drawable.c22)
                    } else if (CardNumber2.equals(23)) {
                        card2.setImageResource(R.drawable.c23)
                    } else if (CardNumber2.equals(24)) {
                        card2.setImageResource(R.drawable.c24)
                    } else if (CardNumber2.equals(25)) {
                        card2.setImageResource(R.drawable.c25)
                    } else if (CardNumber2.equals(26)) {
                        card2.setImageResource(R.drawable.c26)
                    } else if (CardNumber2.equals(27)) {
                        card2.setImageResource(R.drawable.c27)
                    } else if (CardNumber2.equals(28)) {
                        card2.setImageResource(R.drawable.c28)
                    } else if (CardNumber2.equals(29)) {
                        card2.setImageResource(R.drawable.c29)
                    } else {
                        card2.setImageResource(R.drawable.c30)
                    }
                } else if (cardSelected2.equals(3)) {
                    if (CardNumber2.equals(1)) {
                        card3.setImageResource(R.drawable.c1)
                    } else if (CardNumber2.equals(2)) {
                        card3.setImageResource(R.drawable.c2)
                    } else if (CardNumber2.equals(3)) {
                        card3.setImageResource(R.drawable.c3)
                    } else if (CardNumber2.equals(4)) {
                        card3.setImageResource(R.drawable.c4)
                    } else if (CardNumber2.equals(5)) {
                        card3.setImageResource(R.drawable.c5)
                    } else if (CardNumber2.equals(6)) {
                        card3.setImageResource(R.drawable.c6)
                    } else if (CardNumber2.equals(7)) {
                        card3.setImageResource(R.drawable.c7)
                    } else if (CardNumber2.equals(8)) {
                        card3.setImageResource(R.drawable.c8)
                    } else if (CardNumber2.equals(9)) {
                        card3.setImageResource(R.drawable.c9)
                    } else if (CardNumber2.equals(10)) {
                        card3.setImageResource(R.drawable.c10)
                    }else if (CardNumber2.equals(11)) {
                        card3.setImageResource(R.drawable.c11)
                    } else if (CardNumber2.equals(12)) {
                        card3.setImageResource(R.drawable.c12)
                    } else if (CardNumber2.equals(13)) {
                        card3.setImageResource(R.drawable.c13)
                    } else if (CardNumber2.equals(14)) {
                        card3.setImageResource(R.drawable.c14)
                    } else if (CardNumber2.equals(15)) {
                        card3.setImageResource(R.drawable.c15)
                    } else if (CardNumber2.equals(16)) {
                        card3.setImageResource(R.drawable.c16)
                    } else if (CardNumber2.equals(17)) {
                        card3.setImageResource(R.drawable.c17)
                    } else if (CardNumber2.equals(18)) {
                        card3.setImageResource(R.drawable.c18)
                    } else if (CardNumber2.equals(19)) {
                        card3.setImageResource(R.drawable.c19)
                    }  else if (CardNumber2.equals(20)) {
                        card3.setImageResource(R.drawable.c20)
                    } else if (CardNumber2.equals(21)) {
                        card3.setImageResource(R.drawable.c21)
                    } else if (CardNumber2.equals(22)) {
                        card3.setImageResource(R.drawable.c22)
                    } else if (CardNumber2.equals(23)) {
                        card3.setImageResource(R.drawable.c23)
                    } else if (CardNumber2.equals(24)) {
                        card3.setImageResource(R.drawable.c24)
                    } else if (CardNumber2.equals(25)) {
                        card3.setImageResource(R.drawable.c25)
                    } else if (CardNumber2.equals(26)) {
                        card3.setImageResource(R.drawable.c26)
                    } else if (CardNumber2.equals(27)) {
                        card3.setImageResource(R.drawable.c27)
                    } else if (CardNumber2.equals(28)) {
                        card3.setImageResource(R.drawable.c28)
                    } else if (CardNumber2.equals(29)) {
                        card3.setImageResource(R.drawable.c29)
                    } else {
                        card3.setImageResource(R.drawable.c30)
                    }
                } else if (cardSelected2.equals(4)) {
                    if (CardNumber2.equals(1)) {
                        card4.setImageResource(R.drawable.c1)
                    } else if (CardNumber2.equals(2)) {
                        card4.setImageResource(R.drawable.c2)
                    } else if (CardNumber2.equals(3)) {
                        card4.setImageResource(R.drawable.c3)
                    } else if (CardNumber2.equals(4)) {
                        card4.setImageResource(R.drawable.c4)
                    } else if (CardNumber2.equals(5)) {
                        card4.setImageResource(R.drawable.c5)
                    } else if (CardNumber2.equals(6)) {
                        card4.setImageResource(R.drawable.c6)
                    } else if (CardNumber2.equals(7)) {
                        card4.setImageResource(R.drawable.c7)
                    } else if (CardNumber2.equals(8)) {
                        card4.setImageResource(R.drawable.c8)
                    } else if (CardNumber2.equals(9)) {
                        card4.setImageResource(R.drawable.c9)
                    } else if (CardNumber2.equals(10)) {
                        card4.setImageResource(R.drawable.c10)
                    }else if (CardNumber2.equals(11)) {
                        card4.setImageResource(R.drawable.c11)
                    } else if (CardNumber2.equals(12)) {
                        card4.setImageResource(R.drawable.c12)
                    } else if (CardNumber2.equals(13)) {
                        card4.setImageResource(R.drawable.c13)
                    } else if (CardNumber2.equals(14)) {
                        card4.setImageResource(R.drawable.c14)
                    } else if (CardNumber2.equals(15)) {
                        card4.setImageResource(R.drawable.c15)
                    } else if (CardNumber2.equals(16)) {
                        card4.setImageResource(R.drawable.c16)
                    } else if (CardNumber2.equals(17)) {
                        card4.setImageResource(R.drawable.c17)
                    } else if (CardNumber2.equals(18)) {
                        card4.setImageResource(R.drawable.c18)
                    } else if (CardNumber2.equals(19)) {
                        card4.setImageResource(R.drawable.c19)
                    } else if (CardNumber2.equals(20)) {
                        card4.setImageResource(R.drawable.c20)
                    } else if (CardNumber2.equals(21)) {
                        card4.setImageResource(R.drawable.c21)
                    } else if (CardNumber2.equals(22)) {
                        card4.setImageResource(R.drawable.c22)
                    } else if (CardNumber2.equals(23)) {
                        card4.setImageResource(R.drawable.c23)
                    } else if (CardNumber2.equals(24)) {
                        card4.setImageResource(R.drawable.c24)
                    } else if (CardNumber2.equals(25)) {
                        card4.setImageResource(R.drawable.c25)
                    } else if (CardNumber2.equals(26)) {
                        card4.setImageResource(R.drawable.c26)
                    } else if (CardNumber2.equals(27)) {
                        card4.setImageResource(R.drawable.c27)
                    } else if (CardNumber2.equals(28)) {
                        card4.setImageResource(R.drawable.c28)
                    } else if (CardNumber2.equals(29)) {
                        card4.setImageResource(R.drawable.c29)
                    } else {
                        card4.setImageResource(R.drawable.c30)
                    }
                } else {

                }
                        if(numround == 11){
                            submit.setText("Proceed to Final Round")
                        }else {
                            submit.setText("Proceed to Next Round")
                        }
//                Toast.makeText(this, "Round is Over!", Toast.LENGTH_LONG).show()
                    }, 1000
                )
            } else if(cardSelected1 == 4){
                Toast.makeText(this, "Player One has already selected this Card!", Toast.LENGTH_LONG)
                    .show()
            } else {
                Toast.makeText(this, "Both Players have already selected!", Toast.LENGTH_LONG)
                    .show()
            }
        }

        submit.setOnClickListener {
            if (numround.equals(12)){
                pauseOffSet = SystemClock.elapsedRealtime() - chronometer.base
                chronometer.stop()


                message.equals("Player 1 has " + p1points + ". Player 2 has " + p2points + ". Therefore Player 1 Wins!!! Congratualtions!")
                secondActivityIntent.putExtra("Victor", message)
                secondActivityIntent.putExtra("Chrome", chronometer.base)
                round1 = true
                startActivityForResult(secondActivityIntent, 0)
            }else{
                check()
                card1.setImageResource(R.drawable.card_1)
                card2.setImageResource(R.drawable.card_2)
                card3.setImageResource(R.drawable.card_5)
                card4.setImageResource(R.drawable.card_6)
                submit.visibility = View.GONE
                numround = numround + 1
                click = 0
                player1 = false
                player2 = false
                cardSelected1 = 0
                cardSelected2 = 0
                CardNumber1 = 0
                CardNumber2 = 0
                CardName1.equals("")
                CardName2.equals("")
                cd1points = 0
                cd2points = 0
                round.setText("Round: " + numround + " / 12")
                playerone.setText("Player 1: " + p1points)
                playertwo.setText("Player 2: " + p2points)
            }
        }
    }


      private fun check() {
          //Attack Combinations
        if(CardName1.equals("Attack") && CardName2.equals("Attack") || CardName2.equals("Attack") && CardName1.equals("Attack")){
            if(cd2points == cd1points || cd1points == cd2points){
                Toast.makeText(this, "Players 1 & 2 Draw!", Toast.LENGTH_LONG).show()
            }else if(cd1points > cd2points){
                p2points = p2points - cd1points
                Toast.makeText(this, "Player 1 has Won!", Toast.LENGTH_LONG).show()
            }else{
                p1points = p1points - cd2points
                Toast.makeText(this, "Player 2 has Won!", Toast.LENGTH_LONG).show()
            }
        }else if(CardName1.equals("Attack") && CardName2.equals("Defend") || CardName2.equals("Attack") && CardName1.equals("Defend")){
              if(cd1points > cd2points){
                p2points = p2points - (cd1points - cd2points)
                Toast.makeText(this, "Player 1 has Won!", Toast.LENGTH_LONG).show()
            }else{
                p1points = p1points - (cd2points - cd1points)
                Toast.makeText(this, "Player 2 has Won!", Toast.LENGTH_LONG).show()
            }
        }
        //Freeze Possibilities
        else if(CardName1.equals("Rare - Freeze")){
                  Toast.makeText(this, "Players 1 has frozen the domain!", Toast.LENGTH_LONG).show()
              }else if(CardName2.equals("Rare - Freeze")){
            Toast.makeText(this, "Players 2 has frozen the domain!", Toast.LENGTH_LONG).show()
        }
        //Protect Possibilities
        else if(CardName1.equals("Rare - Protect")){
                  Toast.makeText(this, "Player 1 has Protected their points!", Toast.LENGTH_LONG).show()
              }else if(CardName2.equals("Rare - Protect")){
            Toast.makeText(this, "Player 2 has Protected their points!", Toast.LENGTH_LONG).show()
        }
        //Reverse Possibilities
        else if(CardName1.equals("Rare - Reverse") ) {
            Toast.makeText(this, "Player 1 has Reversed the Domain!", Toast.LENGTH_LONG).show()
            if(CardName2.equals("Attack")) {
                p2points = p2points - cd2points
            }else if(CardName2.equals("Defend")) {
                p2points = p2points + cd2points
            }
        }else if(CardName2.equals("Rare - Reverse") ) {
            Toast.makeText(this, "Player 2 has Reversed the Domain!", Toast.LENGTH_LONG).show()
            if(CardName1.equals("Attack")) {
                p1points = p1points - cd1points
            }else if(CardName1.equals("Defend")) {
                p1points = p1points + cd1points
            }
        }
        //Deflect Possibilities
        else if(CardName1.equals("Rare - Deflect")){
            p2points = p2points - cd1points
            Toast.makeText(this, "Player 1 has Deflected the Attack!", Toast.LENGTH_LONG).show()
        }else if(CardName2.equals("Rare - Deflect")){
            p1points = p1points - cd2points
            Toast.makeText(this, "Player 2 has Deflected the Attack!", Toast.LENGTH_LONG).show()
        }
        //Minus Possibilities
        else if(CardName1.equals("Rare - Minus")){
            p2points = p2points - 5
            p1points = p1points - cd2points
            Toast.makeText(this, "Player 1 has pulled a Jinx!", Toast.LENGTH_LONG).show()
        }else if(CardName2.equals("Rare - Minus")){
            p1points = p1points - 5
            p2points = p2points - cd1points
            Toast.makeText(this, "Player 2 has pulled a Jinx!", Toast.LENGTH_LONG).show()
        }
        //Defence Possibilities
        else if(CardName1.equals("Defend") && CardName2.equals("Defend")){
            Toast.makeText(this, "Player 1 & 2 have pulled up a defence!", Toast.LENGTH_LONG).show()
        }
        //Error
        else{
            Toast.makeText(this, "Wagwan!", Toast.LENGTH_LONG).show()
        }
          }



    class Intval(val numSides: Int) {

        fun randomise(): Int {
            return (1..numSides).random()
        }
    }

    private fun randInt() {
        // Create new random Int with 30 possiblities
        val rand = Intval(30)
        val givemeRandom = rand.randomise()

        val taskResource = when (givemeRandom) {
            1 -> {
                CardNumber1 = 1
                cd1points = 2
                CardName1 = "Attack"
            }

            2 -> {
                CardNumber1 = 2
                cd1points = 5
                CardName1 = "Attack"
            }

            3 -> {
                CardNumber1 = 3
                cd1points = 3
                CardName1 = "Attack"
            }

            4 -> {
                CardNumber1 = 4
                cd1points = 1
                CardName1 = "Attack"
            }

            5 -> {
                CardNumber1 = 5
                cd1points = 2
                CardName1 = "Attack"
            }

            6 -> {
                CardNumber1 = 6
                cd1points = 12
                CardName1 = "Attack"
            }

            7 -> {
                CardNumber1 = 7
                cd1points = 3
                CardName1 = "Attack"
            }

            8 -> {
                CardNumber1 = 8
                cd1points = 4
                CardName1 = "Defend"
            }

            9 -> {
                CardNumber1 = 9
                cd1points = 4
                CardName1 = "Attack"
            }

            10 -> {
                CardNumber1 = 10
                cd1points = 5
                CardName1 = "Rare - Minus"
            }

            11 -> {
                CardNumber1 = 11
                cd1points = 7
                CardName1 = "Attack"
            }

            12 -> {
                CardNumber1 = 12
                cd1points = 8
                CardName1 = "Attack"
            }

            13 -> {
                CardNumber1 = 13
                cd1points = 10
                CardName1 = "Attack"
            }

            14 -> {
                CardNumber1 = 14
                cd1points = 3
                CardName1 = "Attack"
            }

            15 -> {
                CardNumber1 = 15
                cd1points = 0
                CardName1 = "Rare - Deflect"
            }

            16 -> {
                CardNumber1 = 16
                cd1points = 6
                CardName1 = "Attack"
            }

            17 -> {
                CardNumber1 = 17
                cd1points = 8
                CardName1 = "Attack"
            }

            18 -> {
                CardNumber1 = 18
                cd1points = 5
                CardName1 = "Attack"
            }

            19 -> {
                CardNumber1 = 19
                cd1points = 6
                CardName1 = "Attack"
            }

            20 -> {
                CardNumber1 = 20
                cd1points = 8
                CardName1 = "Attack"
            }

            21 -> {
                CardNumber1 = 21
                cd1points = 8
                CardName1 = "Attack"
            }

            22 -> {
                CardNumber1 = 22
                cd1points = 0
                CardName1 = "Rare - Freeze"
            }

            23 -> {
                CardNumber1 = 23
                cd1points = 0
                CardName1 = "Rare - Reverse"
            }

            24 -> {
                CardNumber1 = 24
                cd1points = 4
                CardName1 = "Attack"
            }

            25 -> {
                CardNumber1 = 25
                cd1points = 10
                CardName1 = "Attack"
            }

            26 -> {
                CardNumber1 = 26
                cd1points = 0
                CardName1 = "Rare - Protect"
            }

            27 -> {
                CardNumber1 = 27
                cd1points = 12
                CardName1 = "Attack"
            }

            28 -> {
                CardNumber1 = 28
                cd1points = 5
                CardName1 = "Attack"
            }

            29 -> {
                CardNumber1 = 29
                cd1points = 7
                CardName1 = "Defend"
            }

            else -> {
                CardNumber1 = 30
                cd1points = 15
                CardName1 = "Attack"
            }

        }

    }

    private fun randInt1() {
        // Create new random Int with 30 possiblities
        val rand = Intval(30)
        val givemeRandom = rand.randomise()

        val taskResource = when (givemeRandom) {
            1 -> {
                CardNumber2 = 1
                cd2points = 2
                CardName2 = "Attack"
            }

            2 -> {
                CardNumber2 = 2
                cd2points = 5
                CardName2 = "Attack"
            }

            3 -> {
                CardNumber2 = 3
                cd2points = 3
                CardName2 = "Attack"
            }

            4 -> {
                CardNumber2 = 4
                cd2points = 1
                CardName2 = "Attack"
            }

            5 -> {
                CardNumber2 = 5
                cd2points = 2
                CardName2 = "Attack"
            }

            6 -> {
                CardNumber2 = 6
                cd2points = 12
                CardName2 = "Attack"
            }

            7 -> {
                CardNumber2 = 7
                cd2points = 3
                CardName2 = "Attack"
            }

            8 -> {
                CardNumber2 = 8
                cd2points = 4
                CardName2 = "Defend"
            }

            9 -> {
                CardNumber2 = 9
                cd2points = 4
                CardName2 = "Attack"
            }

            10 -> {
                CardNumber2 = 10
                cd2points = 5
                CardName2 = "Rare - Minus"
            }

            11 -> {
                CardNumber2 = 11
                cd2points = 7
                CardName2 = "Attack"
            }

            12 -> {
                CardNumber2 = 12
                cd2points = 8
                CardName2 = "Attack"
            }

            13 -> {
                CardNumber2 = 13
                cd2points = 10
                CardName2 = "Attack"
            }

            14 -> {
                CardNumber2 = 14
                cd2points = 3
                CardName2 = "Attack"
            }

            15 -> {
                CardNumber2 = 15
                cd2points = 0
                CardName2 = "Rare - Deflect"
            }

            16 -> {
                CardNumber2 = 16
                cd2points = 6
                CardName2 = "Attack"
            }

            17 -> {
                CardNumber2 = 17
                cd2points = 8
                CardName2 = "Attack"
            }

            18 -> {
                CardNumber2 = 18
                cd2points = 5
                CardName2 = "Attack"
            }

            19 -> {
                CardNumber2 = 19
                cd2points = 6
                CardName2 = "Attack"
            }

            20 -> {
                CardNumber2 = 20
                cd2points = 8
                CardName2 = "Attack"
            }

            21 -> {
                CardNumber2 = 21
                cd2points = 8
                CardName2 = "Attack"
            }

            22 -> {
                CardNumber2 = 22
                cd2points = 0
                CardName2 = "Rare - Freeze"
            }

            23 -> {
                CardNumber2 = 23
                cd2points = 0
                CardName2 = "Rare - Reverse"
            }

            24 -> {
                CardNumber2 = 24
                cd2points = 4
                CardName2 = "Attack"
            }

            25 -> {
                CardNumber2 = 25
                cd2points = 10
                CardName2 = "Attack"
            }

            26 -> {
                CardNumber2 = 26
                cd2points = 0
                CardName2 = "Rare - Protect"
            }

            27 -> {
                CardNumber2 = 27
                cd2points = 12
                CardName2 = "Attack"
            }

            28 -> {
                CardNumber2 = 28
                cd2points = 5
                CardName2 = "Attack"
            }

            29 -> {
                CardNumber2 = 29
                cd2points = 7
                CardName2 = "Defend"
            }

            else -> {
                CardNumber2 = 30
                cd2points = 15
                CardName2 = "Attack"
            }

        }

    }

}
