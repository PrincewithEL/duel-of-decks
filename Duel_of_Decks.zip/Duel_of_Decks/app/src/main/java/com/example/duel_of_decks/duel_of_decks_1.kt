package com.example.duel_of_decks

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.example.shane.R

private lateinit var listIntent: Intent

class duel_of_decks_1 : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_duel_of_decks_1)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        val nextButton: Button = findViewById(R.id.nextbt)
        val desc: TextView = findViewById(R.id.desc)


        nextButton.setOnClickListener {

            nextButton.setText("Let's Duel!")
            desc.setText(R.string.duel_text2)
            nextButton.setOnClickListener {
            gotoDOD2()
            }

        }

    }

    private fun gotoDOD2(){
        listIntent = Intent(this, duel_of_decks_2::class.java)
        startActivity(listIntent)
    }

}